/* UI giống hình mẫu — Dữ liệu Chương 2–19 */
const REMEDIES = [
  {
    "id": "ai_thanh_long_thang",
    "name": "Đại thanh long thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân ôn giải biểu",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt",
      "cơ thể đau mỏi",
      "không ra mồ hôi",
      "bứt rứt khó chịu (phiền táo)",
      "miệng hơi khát"
    ],
    "effects": [
      "phát hãn giải biểu",
      "thanh nhiệt trừ phiền"
    ],
    "indication": "chứng ngoại cảm phong hàn biểu thực kèm theo có lý nhiệt gây bứt rứt, khó chịu",
    "herbs": [
      {
        "name": "Ma hoàng",
        "dose": "16g"
      },
      {
        "name": "Quế chi",
        "dose": "8g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "8g"
      },
      {
        "name": "Đại táo",
        "dose": "8g"
      },
      {
        "name": "Hạnh nhân",
        "dose": "8g"
      },
      {
        "name": "Thạch cao",
        "dose": "16g"
      },
      {
        "name": "Sinh khương",
        "dose": "8g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 3 lần; thường ra mồ hôi sau khi uống là dừng",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "cuu_vi_khuong_hoat_thang",
    "name": "Cửu vị khương hoạt thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân ôn giải biểu",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt",
      "đau đầu",
      "gáy cứng",
      "không có mồ hôi",
      "cơ thể đau mỏi",
      "miệng đắng hơi khát"
    ],
    "effects": [
      "phát hãn",
      "trừ thấp kiêm thanh lý nhiệt"
    ],
    "indication": "phát hãn, trừ thấp kiêm thanh lý nhiệt. Bài thuốc điều trị chứng ngoại cảm phong hàn thấp tà gây đau đầu, gáy cứng, không có mồ hôi",
    "herbs": [
      {
        "name": "Khương hoạt",
        "dose": "12g"
      },
      {
        "name": "Thương thuật",
        "dose": "12g"
      },
      {
        "name": "Phòng phong",
        "dose": "12g"
      },
      {
        "name": "Tế tân",
        "dose": "4g"
      },
      {
        "name": "Xuyên khung",
        "dose": "8g"
      },
      {
        "name": "Bạch chỉ",
        "dose": "8g"
      },
      {
        "name": "Sinh địa",
        "dose": "8g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "8g"
      },
      {
        "name": "Cam thảo",
        "dose": "6g"
      }
    ],
    "usage": "Gia thêm 3 lát Sinh khương và 3 củ hành sắc uống",
    "analysis": "Khương hoạt (Quân) phát tán phong hàn; Phòng phong, Thương thuật (Thần) hỗ trợ trừ thấp; Tế tân, Xuyên khung, Bạch chỉ (Tá) trừ phong chỉ thống; Sinh địa, Hoàng cầm (Tá) thanh nhiệt ở phần khí; Cam thảo (Sứ) điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "gia_giam_uy_di_thang",
    "name": "Gia giảm uy di thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Phù chính giải biểu",
    "symptoms": [
      "Đầu đau",
      "người nóng",
      "hơi sợ gió",
      "sợ lạnh",
      "không ra mồ hôi hoặc mồ hôi ít",
      "ho khan",
      "tâm phiền",
      "miệng khát",
      "họng khô"
    ],
    "effects": [
      "tư âm thanh nhiệt",
      "phát hãn giải biểu"
    ],
    "indication": "người âm hư bị cảm thụ phong nhiệt gây ho khan, miệng khát, họng khô",
    "herbs": [
      {
        "name": "Uy di (Ngọc trúc)",
        "dose": "8-12g"
      },
      {
        "name": "Cát cánh",
        "dose": "4-6g"
      },
      {
        "name": "Thông bạch",
        "dose": "2-3 củ"
      },
      {
        "name": "Đậu xị",
        "dose": "12-16g"
      },
      {
        "name": "Bạch vi",
        "dose": "2-4g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      },
      {
        "name": "Đại táo",
        "dose": "2 quả"
      },
      {
        "name": "Bạc hà",
        "dose": "4g"
      }
    ],
    "usage": "Sắc uống",
    "analysis": "Ngọc trúc (Quân) tư âm sinh tân; Thông bạch, Đậu xị, Bạc hà (Thần) phát hãn giải biểu; Bạch vi (Tá) thanh nhiệt; Cam thảo, Đại táo (Sứ) điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "ma_hanh_thach_cam_thang",
    "name": "Ma hạnh thạch cam thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân lương giải biểu",
    "symptoms": [
      "Phát sốt",
      "ho",
      "khó thở",
      "miệng khát",
      "phiền táo",
      "chất lưỡi đỏ",
      "rêu vàng"
    ],
    "effects": [
      "thanh nhiệt",
      "tuyên phế",
      "bình suyễn"
    ],
    "indication": "thanh nhiệt, tuyên phế, bình suyễn. Bài thuốc được chỉ định cho trường hợp ngoại tỏa nội nhiệt dẫn đến phát sốt, ho, khó thở",
    "herbs": [
      {
        "name": "Ma hoàng",
        "dose": "4-12g"
      },
      {
        "name": "Hạnh nhân",
        "dose": "12g"
      },
      {
        "name": "Thạch cao",
        "dose": "30g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      }
    ],
    "usage": "Làm thang sắc uống, ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ma_hoang_phu_tu_te_tan_thang",
    "name": "Ma hoàng phụ tử tế tân thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Phù chính giải biểu",
    "symptoms": [
      "Sợ lạnh nhiều",
      "phát sốt hoặc hơi sốt",
      "đau đầu",
      "mạch trầm"
    ],
    "effects": [
      "trợ dương",
      "giải biểu"
    ],
    "indication": "người có thận dương hư lại bị ngoại cảm phong tà gây sợ lạnh nhiều",
    "herbs": [
      {
        "name": "Ma hoàng",
        "dose": "8g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "8g"
      },
      {
        "name": "Tế tân",
        "dose": "4g"
      }
    ],
    "usage": "Làm thang sắc uống, ngày 1 thang chia 3 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ma_hoang_thang",
    "name": "Ma hoàng thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân ôn giải biểu",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt",
      "không ra mồ hôi",
      "ho",
      "khó thở",
      "cơ thể đau mỏi"
    ],
    "effects": [
      "phát hãn giải biểu",
      "tuyên phế",
      "bình suyễn"
    ],
    "indication": "phát hãn giải biểu, tuyên phế, bình suyễn. Bài thuốc này được chỉ định điều trị chứng cảm mạo phong hàn với các triệu chứng sợ lạnh, phát sốt, không ra mồ hôi, ho, khó thở, cơ thể đau mỏi",
    "herbs": [
      {
        "name": "Ma hoàng",
        "dose": "4-12g"
      },
      {
        "name": "Quế chi",
        "dose": "4-12g"
      },
      {
        "name": "Hạnh nhân",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      }
    ],
    "usage": "Mỗi ngày sắc 1 thang, uống chia 2 lần",
    "analysis": "Ma hoàng (Quân) có tính vị tân ôn giúp phát tán phong hàn và tuyên phế bình suyễn; Quế chi (Thần) trợ giúp Ma hoàng phát hãn và ôn thông kinh lạc; Hạnh nhân (Tá) giúp tuyên giáng phế khí, phối hợp với Ma hoàng để giải quyết chứng ho và khó thở; Cam thảo (Sứ) điều hòa các vị thuốc và làm giảm tính mãnh liệt của Ma hoàng",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngan_kieu_tan",
    "name": "Ngân kiều tán",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân lương giải biểu",
    "symptoms": [
      "Phát sốt",
      "ho",
      "đau họng",
      "viêm đường hô hấp trên thời kỳ đầu"
    ],
    "effects": [
      "tân lương giải biểu",
      "thanh nhiệt",
      "giải độc"
    ],
    "indication": "ngoại cảm phong nhiệt thời kỳ đầu có sốt, ho, đau họng",
    "herbs": [
      {
        "name": "Kim ngân hoa",
        "dose": "40g"
      },
      {
        "name": "Liên kiều",
        "dose": "40g"
      },
      {
        "name": "Đậu xị",
        "dose": "20g"
      },
      {
        "name": "Ngưu bàng tử",
        "dose": "25g"
      },
      {
        "name": "Trúc diệp",
        "dose": "16g"
      },
      {
        "name": "Kinh giới",
        "dose": "16g"
      },
      {
        "name": "Bạc hà",
        "dose": "25g"
      },
      {
        "name": "Cát cánh",
        "dose": "25g"
      },
      {
        "name": "Cam thảo",
        "dose": "20g"
      }
    ],
    "usage": "Tán bột, mỗi ngày uống 20g, chia 2 lần. Nếu bệnh nặng uống thêm 1 lần vào ban đêm. Cũng có thể sắc uống 1 - 2 thang/ngày, chia 2 - 4 lần",
    "analysis": "Kim ngân hoa, Liên kiều (Quân) thanh nhiệt giải độc; Kinh giới, Đậu xị, Bạc hà (Thần) giải biểu; Cát cánh, Cam thảo, Trúc diệp, Lô căn là Tá và Sứ",
    "contra": "",
    "note": ""
  },
  {
    "id": "nhan_sam_bai_oc_tan",
    "name": "Nhân sâm bại độc tán",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Phù chính giải biểu",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt không ra mồ hôi",
      "đầu và cổ gáy cứng đau",
      "cơ thể đau mỏi",
      "ngực bụng đầy tức",
      "mũi ngạt",
      "ho có đờm"
    ],
    "effects": [
      "ích khí giải biểu",
      "tán phong trừ thấp"
    ],
    "indication": "ích khí giải biểu, tán phong trừ thấp. Bài thuốc điều trị cho người chính khí bất túc bị ngoại cảm phong hàn thấp tà",
    "herbs": [
      {
        "name": "Sài hồ",
        "dose": ""
      },
      {
        "name": "Tiền hồ",
        "dose": ""
      },
      {
        "name": "Xuyên khung",
        "dose": ""
      },
      {
        "name": "Chỉ xác",
        "dose": ""
      },
      {
        "name": "Khương hoạt",
        "dose": ""
      },
      {
        "name": "Độc hoạt",
        "dose": ""
      },
      {
        "name": "Phục linh",
        "dose": ""
      },
      {
        "name": "Cát cánh",
        "dose": ""
      },
      {
        "name": "Đảng sâm",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "6g"
      }
    ],
    "usage": "Có thể tán bột hãm nước sôi uống mỗi lần 8g, hoặc gia thêm Sinh khương, Bạc hà sắc uống ngày 1 thang chia 2 lần",
    "analysis": "Khương hoạt, Độc hoạt (Quân) giải biểu trừ thấp; Xuyên khung, Sài hồ (Thần) khu phong; Đảng sâm (Thần) ích khí phù chính",
    "contra": "",
    "note": ""
  },
  {
    "id": "que_chi_thang",
    "name": "Quế chi thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân ôn giải biểu",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt",
      "có ra mồ hôi",
      "sợ gió",
      "tắc ngạt mũi",
      "chảy nước mũi",
      "họng khô"
    ],
    "effects": [
      "giải cơ phát biểu",
      "điều hòa dinh vệ"
    ],
    "indication": "chứng cảm mạo phong hàn thể biểu hư có sợ lạnh, phát sốt, ra mồ hôi, sợ gió",
    "herbs": [
      {
        "name": "Quế chi",
        "dose": "6-12g"
      },
      {
        "name": "Bạch thược",
        "dose": "8-12g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Đại táo",
        "dose": "4-6 quả"
      },
      {
        "name": "Chích cam thảo",
        "dose": "8g"
      }
    ],
    "usage": "Mỗi ngày sắc 1 thang, uống chia 2 lần. Sau khi uống ăn một bát cháo nóng nhỏ để hỗ trợ ra mồ hôi râm rấp",
    "analysis": "Quế chi (Quân) giải cơ phát biểu, ôn thông kinh mạch; Bạch thược (Quân) vị chua đắng, tính hơi lạnh giúp liễm âm hòa dinh; Sinh khương (Thần) trợ Quế chi phát tán tà khí; Đại táo (Thần) trợ Bạch thược ích âm; Cam thảo (Sứ) điều hòa trung tiêu và các vị thuốc",
    "contra": "",
    "note": ""
  },
  {
    "id": "sai_cat_giai_co_thang",
    "name": "Sài cát giải cơ thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân lương giải biểu",
    "symptoms": [
      "Sốt cao",
      "sợ lạnh",
      "toàn thân nóng",
      "không ra mồ hôi",
      "đau đầu",
      "mỏi khớp",
      "mũi khô",
      "miệng đắng"
    ],
    "effects": [
      "giải cơ",
      "thanh nhiệt"
    ],
    "indication": "giải cơ, thanh nhiệt. Bài thuốc điều trị chứng ngoại cảm phát sốt khi biểu chứng chưa giải mà lý nhiệt đã hình thành",
    "herbs": [
      {
        "name": "Sài hồ",
        "dose": "4-12g"
      },
      {
        "name": "Cát căn",
        "dose": "8-16g"
      },
      {
        "name": "Khương hoạt",
        "dose": "8-16g"
      },
      {
        "name": "Bạch chỉ",
        "dose": "4g"
      },
      {
        "name": "Cát cánh",
        "dose": "4-8g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "8-16g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-8g"
      },
      {
        "name": "Thạch cao",
        "dose": "20g"
      },
      {
        "name": "Xích thược",
        "dose": "8-12g"
      }
    ],
    "usage": "Làm thang sắc uống, ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "sam_to_am",
    "name": "Sâm tô ẩm",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Phù chính giải biểu",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt",
      "không có mồ hôi",
      "đau đầu",
      "ngạt mũi",
      "ho",
      "đờm trắng",
      "ngực đầy tức",
      "người mệt mỏi",
      "vô lực",
      "khí đoản"
    ],
    "effects": [
      "ích khí giải biểu",
      "lý khí hóa đàm"
    ],
    "indication": "người cơ thể suy nhược bị ngoại cảm phong hàn kèm có đàm ẩm bên trong",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Tô diệp",
        "dose": "12g"
      },
      {
        "name": "Cát căn",
        "dose": "12g"
      },
      {
        "name": "Trần bì",
        "dose": "8g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "6g"
      },
      {
        "name": "Tiền hồ",
        "dose": "8g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "8g"
      },
      {
        "name": "Bắc mộc hương",
        "dose": "6g"
      },
      {
        "name": "Chỉ xác",
        "dose": "8g"
      },
      {
        "name": "Cát cánh",
        "dose": "8g"
      }
    ],
    "usage": "Có thể dùng bột hãm (12g/lần) hoặc dùng thuốc sắc gia thêm Sinh khương, Đại táo, uống nóng",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tang_cuc_am",
    "name": "Tang cúc ẩm",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân lương giải biểu",
    "symptoms": [
      "Hơi sợ lạnh",
      "phát sốt",
      "đau đầu",
      "ngạt mũi",
      "ho (triệu chứng chính là ho)"
    ],
    "effects": [
      "sơ phong",
      "thanh nhiệt",
      "tuyên phế",
      "chỉ khái"
    ],
    "indication": "cảm mạo phong nhiệt thời kỳ đầu với triệu chứng ho là chủ yếu",
    "herbs": [
      {
        "name": "Tang diệp",
        "dose": "8-12g"
      },
      {
        "name": "Cúc hoa",
        "dose": "4-8g"
      },
      {
        "name": "Liên kiều",
        "dose": "8-16g"
      },
      {
        "name": "Bạc hà",
        "dose": "4-8g"
      },
      {
        "name": "Hạnh nhân",
        "dose": "12g"
      },
      {
        "name": "Cát cánh",
        "dose": "4-12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-6g"
      },
      {
        "name": "Lô căn",
        "dose": "1 cành rễ"
      }
    ],
    "usage": "Làm thang sắc uống, ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thang_ma_cat_can_thang",
    "name": "Thăng ma cát căn thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân lương giải biểu",
    "symptoms": [
      "Phát sốt",
      "sợ gió",
      "hầu họng khô rát",
      "mắt đỏ",
      "nhiều rỉ (dùng cho sởi thời kỳ khởi phát chưa mọc hết)"
    ],
    "effects": [
      "giải cơ",
      "thấu chẩn"
    ],
    "indication": "bệnh ma chẩn (sởi) thời kỳ khởi phát chưa mọc hết ban hoặc ban mới nổi chưa lặn",
    "herbs": [
      {
        "name": "Thăng ma",
        "dose": "12g"
      },
      {
        "name": "Cát căn",
        "dose": "12g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "6g"
      }
    ],
    "usage": "Nếu dùng thuốc bột, mỗi lần uống 16g hãm uống. Nếu dùng thuốc sắc, ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_thanh_long_thang",
    "name": "Tiểu thanh long thang",
    "chapterNumber": 2,
    "chapterTitle": "Bài thuốc giải biểu",
    "group": "Giải biểu",
    "subgroup": "Tân ôn giải biểu",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt",
      "không có mồ hôi",
      "ho",
      "khạc đờm trắng loãng",
      "hơi khó thở",
      "mặt và chi dưới có thể sưng nề"
    ],
    "effects": [
      "giải biểu tán hàn",
      "ôn phế hóa ẩm"
    ],
    "indication": "giải biểu tán hàn, ôn phế hóa ẩm. Bài thuốc được chỉ định cho chứng ngoại cảm phong hàn có thủy ẩm ở bên trong gây ho, khạc đờm trắng loãng",
    "herbs": [
      {
        "name": "Ma hoàng",
        "dose": "8g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Quế chi",
        "dose": "8g"
      },
      {
        "name": "Tế tân",
        "dose": "6g"
      },
      {
        "name": "Can khương",
        "dose": "8g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "6g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "6g"
      },
      {
        "name": "Ngũ vị tử",
        "dose": "6g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 3 lần",
    "analysis": "Ma hoàng, Quế chi (Quân) phát hãn giải biểu, tuyên phế bình suyễn; Can khương, Tế tân (Thần) ôn phế hóa ẩm, giúp giải tỏa thủy ẩm ở bên trong; Bán hạ chế trừ thấp hóa đàm, Ngũ vị tử liễm phế chỉ khái (Tá) để ngăn phế khí tiêu tán quá mức; Bạch thược phối hợp điều hòa dinh vệ; Cam thảo (Sứ) điều hòa tính nóng của các vị thuốc",
    "contra": "",
    "note": ""
  },
  {
    "id": "ao_xich_tan",
    "name": "Đạo xích tán",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở tạng phủ",
    "symptoms": [
      "Tâm phiền",
      "mất ngủ",
      "miệng lưỡi sinh mụn loét",
      "đi tiểu ít",
      "đỏ và có cảm giác đau"
    ],
    "effects": [
      "thanh tâm hỏa",
      "lợi tiểu tiện"
    ],
    "indication": "thanh tâm hỏa, lợi tiểu tiện. Bài thuốc điều trị chứng tâm hỏa vượng gây tâm phiền, mất ngủ, tiểu đỏ",
    "herbs": [
      {
        "name": "Sinh địa",
        "dose": "16-30g"
      },
      {
        "name": "Mộc thông",
        "dose": "8-12g"
      },
      {
        "name": "Trúc diệp",
        "dose": "8-12g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      }
    ],
    "usage": "Thường dùng dưới dạng thang sắc uống, mỗi ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bach_au_ong_thang",
    "name": "Bạch đầu ông thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở tạng phủ",
    "symptoms": [
      "Đau quặn bụng",
      "mót rặn",
      "hậu môn nóng rát",
      "phân có máu mủ"
    ],
    "effects": [
      "thanh thấp nhiệt",
      "lương huyết",
      "giải độc",
      "chỉ lỵ"
    ],
    "indication": "hội chứng lỵ gây đau quặn bụng, mót rặn, phân máu mủ",
    "herbs": [
      {
        "name": "Bạch đầu ông",
        "dose": "12-20g"
      },
      {
        "name": "Hoàng bá",
        "dose": "12g"
      },
      {
        "name": "Hoàng liên",
        "dose": "4-8g"
      },
      {
        "name": "Tần bì",
        "dose": "12-16g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia làm 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bach_ho_thang",
    "name": "Bạch hổ thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở phần khí Thanh nhiệt tả hỏa",
    "symptoms": [
      "Sốt cao",
      "khát nước",
      "thích uống nước mát",
      "mặt đỏ",
      "mồ hôi ra nhiều",
      "sợ nóng",
      "mạch hồng đại"
    ],
    "effects": [
      "thanh khí nhiệt",
      "tả vị hỏa",
      "sinh tân chỉ khát"
    ],
    "indication": "thanh khí nhiệt, tả vị hỏa, sinh tân chỉ khát. Bài thuốc được chỉ định khi nhiệt tà xâm phạm vào khí phận gây sốt cao, khát nước, mạch hồng đại",
    "herbs": [
      {
        "name": "Thạch cao",
        "dose": "30g"
      },
      {
        "name": "Tri mẫu",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Ngạnh mễ",
        "dose": "9g"
      }
    ],
    "usage": "Sắc uống, ngày 1 thang chia 2 lần",
    "analysis": "Thạch cao (Quân) dùng liều cao để thanh đại nhiệt ở khí phân; Tri mẫu (Thần) đắng lạnh giúp trợ thanh hỏa và sinh tân dịch; Cam thảo, Ngạnh mễ (Tá, Sứ) ích vị, hòa trung, ngăn chặn tính đại hàn của bài thuốc làm tổn thương tỳ vị",
    "contra": "",
    "note": ""
  },
  {
    "id": "duong_am_thanh_phe_thang",
    "name": "Dưỡng âm thanh phế thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt hư nhiệt",
    "symptoms": [
      "Ho khan",
      "đau họng",
      "họng có màng trắng khó bóc (bạch hầu hoặc viêm họng mãn)"
    ],
    "effects": [
      "dưỡng âm thanh phế",
      "lương huyết giải độc"
    ],
    "indication": "viêm họng mãn tính, ho khan do phế âm hư",
    "herbs": [
      {
        "name": "Sinh địa",
        "dose": "12-20g"
      },
      {
        "name": "Mạch môn",
        "dose": "8-16g"
      },
      {
        "name": "Huyền sâm",
        "dose": "8-16g"
      },
      {
        "name": "Đan bì",
        "dose": "8-16g"
      },
      {
        "name": "Bạch thược (sao)",
        "dose": "8-12g"
      },
      {
        "name": "Bối mẫu",
        "dose": "12-16g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-12g"
      },
      {
        "name": "Bạc hà",
        "dose": "4-6g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "Sinh địa, Mạch môn, Huyền sâm (Quân) dưỡng âm thanh phế; Đan bì, Bạch thược, Bối mẫu, Bạc hà là các vị Tá trợ giúp",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoang_lien_giai_oc_thang",
    "name": "Hoàng liên giải độc thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt giải độc",
    "symptoms": [
      "Sốt cao",
      "vật vã",
      "mê sảng",
      "mụn nhọt",
      "nôn ra máu",
      "chảy máu cam"
    ],
    "effects": [
      "tả hỏa giải độc",
      "thanh thấp nhiệt"
    ],
    "indication": "tả hỏa giải độc, thanh thấp nhiệt. Bài thuốc trị các chứng thực nhiệt hỏa độc gây vật vã, mê sảng hoặc mụn nhọt",
    "herbs": [
      {
        "name": "Hoàng liên",
        "dose": "4g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "8-16g"
      },
      {
        "name": "Hoàng bá",
        "dose": "8g"
      },
      {
        "name": "Chi tử",
        "dose": "8-16g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "Hoàng liên (Quân) tả hỏa trung tiêu; Hoàng cầm (Thần) tả hỏa thượng tiêu; Hoàng bá (Thần) tả hỏa hạ tiêu; Chi tử (Tá, Sứ) thông đạt hỏa ra ngoài",
    "contra": "",
    "note": ""
  },
  {
    "id": "long_om_ta_can_thang",
    "name": "Long đởm tả can thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở tạng phủ",
    "symptoms": [
      "Đau đầu",
      "đau vùng mạng sườn",
      "mắt đỏ",
      "miệng đắng",
      "tai đau sưng",
      "nước tiểu đục",
      "ngứa đau bộ phận sinh dục"
    ],
    "effects": [
      "tả can đởm thực hỏa",
      "thanh lợi hạ tiêu thấp nhiệt"
    ],
    "indication": "tả can đởm thực hỏa, thanh lợi hạ tiêu thấp nhiệt. Bài thuốc trị chứng can kinh hỏa thịnh gây mắt đỏ, tai ù, đau mạng sườn hoặc đới hạ",
    "herbs": [
      {
        "name": "Long đởm thảo",
        "dose": "2-8g"
      },
      {
        "name": "Chi tử",
        "dose": "8-16g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "8-16g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-8g"
      },
      {
        "name": "Sài hồ",
        "dose": "4-12g"
      },
      {
        "name": "Sinh địa",
        "dose": "12-20g"
      },
      {
        "name": "Xa tiền",
        "dose": "12-20g"
      },
      {
        "name": "Đương quy",
        "dose": "8-16g"
      },
      {
        "name": "Trạch tả",
        "dose": "8-16g"
      },
      {
        "name": "Mộc thông",
        "dose": "8-12g"
      }
    ],
    "usage": "Sắc uống, mỗi ngày 1 thang chia 2 lần",
    "analysis": "Long đởm thảo (Quân) chuyên tả can đởm thực hỏa và thấp nhiệt hạ tiêu; Hoàng cầm, Chi tử (Thần) đắng lạnh trợ giúp thanh hỏa; Sinh địa, Đương quy dưỡng huyết tư âm để bảo vệ can huyết; Mộc thông, Xa tiền tử, Trạch tả (Tá) dẫn thấp nhiệt ra ngoài qua đường tiểu; Sài hồ (Sứ) dẫn thuốc vào kinh can",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngan_kieu_thach_hoc_thang",
    "name": "Ngân kiều thạch học thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt hư nhiệt",
    "symptoms": [
      "Viêm nhiễm đường tiết niệu kéo dài",
      "thận âm hư tổn"
    ],
    "effects": [
      "dưỡng âm",
      "tư thận",
      "thanh nhiệt giải độc"
    ],
    "indication": "viêm nhiễm mãn tính đường tiết niệu thể thận âm hư",
    "herbs": [
      {
        "name": "Kim ngân hoa",
        "dose": "12-20g"
      },
      {
        "name": "Liên kiều",
        "dose": "12-20g"
      },
      {
        "name": "Thạch hộc",
        "dose": "12-20g"
      },
      {
        "name": "Đan bì",
        "dose": "8-12g"
      },
      {
        "name": "Phục linh",
        "dose": "16-24g"
      },
      {
        "name": "Thục địa",
        "dose": "20g"
      },
      {
        "name": "Sơn thù",
        "dose": "8-12g"
      },
      {
        "name": "Hoài sơn",
        "dose": "12g"
      },
      {
        "name": "Trạch tả",
        "dose": "8-16g"
      }
    ],
    "usage": "Sắc uống mỗi ngày 1 thang, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngoc_nu_tien",
    "name": "Ngọc nữ tiễn",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở tạng phủ",
    "symptoms": [
      "Phiền nhiệt",
      "khát nước",
      "đầu đau",
      "lợi sưng đau",
      "chảy máu chân răng",
      "tiêu khát"
    ],
    "effects": [
      "tả vị nhiệt",
      "tư âm"
    ],
    "indication": "tả vị nhiệt, tư âm. Bài thuốc trị vị nhiệt gây âm hư dẫn đến đau răng, khát nước, tiêu khát",
    "herbs": [
      {
        "name": "Thạch cao",
        "dose": "12-20g"
      },
      {
        "name": "Thục địa",
        "dose": "12-20g"
      },
      {
        "name": "Mạch môn",
        "dose": "8g"
      },
      {
        "name": "Tri mẫu",
        "dose": "8g"
      },
      {
        "name": "Ngưu tất",
        "dose": "8g"
      }
    ],
    "usage": "Sắc uống, ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngu_vi_tieu_oc_am",
    "name": "Ngũ vị tiêu độc ẩm",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt giải độc",
    "symptoms": [
      "Các loại mụn nhọt",
      "tại chỗ sưng nóng đỏ đau",
      "toàn thân phát sốt"
    ],
    "effects": [
      "thanh nhiệt giải độc",
      "tiêu tán mụn nhọt"
    ],
    "indication": "các loại mụn nhọt sưng nóng đỏ đau",
    "herbs": [
      {
        "name": "Kim ngân hoa",
        "dose": "12-20g"
      },
      {
        "name": "Cúc hoa (dã)",
        "dose": "20g"
      },
      {
        "name": "Bồ công anh",
        "dose": "20g"
      },
      {
        "name": "Tử hoa địa đinh",
        "dose": "20g"
      },
      {
        "name": "Tử bối thiên (Quỳ tử)",
        "dose": "8g"
      }
    ],
    "usage": "Sắc uống",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "nhan_tran_cao_thang",
    "name": "Nhân trần cao thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở tạng phủ",
    "symptoms": [
      "Người nóng",
      "phát sốt",
      "mặt mắt toàn thân vàng",
      "nước tiểu vàng đỏ",
      "đại tiện bí kết",
      "miệng khát",
      "bụng chướng"
    ],
    "effects": [
      "thanh thấp nhiệt",
      "thoái hoàng đản"
    ],
    "indication": "chứng dương hoàng (vàng da do thấp nhiệt)",
    "herbs": [
      {
        "name": "Nhân trần",
        "dose": "20-30g"
      },
      {
        "name": "Chi tử",
        "dose": "10-15g"
      },
      {
        "name": "Đại hoàng",
        "dose": "5-10g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia làm 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ta_bach_tan",
    "name": "Tả bạch tán",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở tạng phủ",
    "symptoms": [
      "Ho khạc đờm",
      "thậm chí khó thở",
      "khạc ra máu",
      "miệng khô",
      "môi khô",
      "chất lưỡi đỏ sẫm"
    ],
    "effects": [
      "tả phế hỏa",
      "thanh hư nhiệt",
      "chỉ khái",
      "bình suyễn"
    ],
    "indication": "chứng phế nhiệt gây ho khạc đờm, họng khô",
    "herbs": [
      {
        "name": "Địa cốt bì",
        "dose": "8-16g"
      },
      {
        "name": "Tang bạch bì",
        "dose": "8-16g"
      },
      {
        "name": "Ngạnh mễ",
        "dose": "20g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-6g"
      }
    ],
    "usage": "Thường dùng dạng thang sắc, mỗi ngày uống 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "te_giac_ia_hoang_thang",
    "name": "Tê giác địa hoàng thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt lương huyết Phần dinh và phần huyết",
    "symptoms": [
      "Sốt cao",
      "mê sảng",
      "xuất huyết dưới da (ban chẩn)",
      "nôn ra máu",
      "chảy máu cam",
      "đi ngoài ra máu"
    ],
    "effects": [
      "thanh nhiệt giải độc",
      "lương huyết tán ứ"
    ],
    "indication": "nhiệt nhập phần huyết gây xuất huyết, nôn ra máu, chảy máu cam",
    "herbs": [
      {
        "name": "Sừng tê giác (mài)",
        "dose": "1.5-4g"
      },
      {
        "name": "Thược dược (Xích thược)",
        "dose": "8-16g"
      },
      {
        "name": "Đan bì",
        "dose": "16g"
      },
      {
        "name": "Sinh địa",
        "dose": "20g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang chia làm 3 lần",
    "analysis": "Sừng tê giác (Quân) thanh tâm lương huyết; Sinh địa (Thần) dưỡng âm; Xích thược, Đan bì (Tá) lương huyết hoạt huyết",
    "contra": "",
    "note": ""
  },
  {
    "id": "thanh_cot_tan",
    "name": "Thanh cốt tán",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt hư nhiệt",
    "symptoms": [
      "Sốt âm ỉ",
      "sốt về chiều",
      "lòng bàn chân bàn tay nóng",
      "gò má đỏ",
      "ra mồ hôi trộm",
      "gầy yếu"
    ],
    "effects": [
      "thanh hư nhiệt",
      "thoái cốt trưng dưỡng âm",
      "thanh hỏa"
    ],
    "indication": "chứng âm hư nội nhiệt trong lao phổi, sốt âm ỉ, mồ hôi trộm",
    "herbs": [
      {
        "name": "Ngân sài hồ",
        "dose": "8-16g"
      },
      {
        "name": "Hồ hoàng liên",
        "dose": "4-12g"
      },
      {
        "name": "Tần giao",
        "dose": "6-12g"
      },
      {
        "name": "Miết giáp",
        "dose": "8-16g"
      },
      {
        "name": "Địa cốt bì",
        "dose": "8-16g"
      },
      {
        "name": "Thanh hao",
        "dose": "6-12g"
      },
      {
        "name": "Tri mẫu",
        "dose": "8-16g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-8g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "Ngân sài hồ (Quân) thanh nhiệt thoái cốt chưng; Thanh hao, Tần giao, Địa cốt bì, Hồ hoàng liên, Tri mẫu (Thần) thanh hư nhiệt",
    "contra": "",
    "note": ""
  },
  {
    "id": "thanh_dinh_thang",
    "name": "Thanh dinh thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt lương huyết Phần dinh và phần huyết",
    "symptoms": [
      "Sốt cao",
      "phiền táo",
      "thậm chí mê sảng",
      "chất lưỡi đỏ sẫm"
    ],
    "effects": [
      "thanh nhiệt giải độc",
      "lương dinh",
      "thanh tâm"
    ],
    "indication": "thanh nhiệt giải độc, lương dinh, thanh tâm. Bài thuốc trị bệnh ôn nhiệt tà xâm nhập phần dinh gây sốt cao, phiền táo, mê sảng",
    "herbs": [
      {
        "name": "Sừng tê giác (mài)",
        "dose": "1-4g"
      },
      {
        "name": "Sinh địa",
        "dose": "20-40g"
      },
      {
        "name": "Huyền sâm",
        "dose": "8-16g"
      },
      {
        "name": "Đan sâm",
        "dose": "8-20g"
      },
      {
        "name": "Trúc diệp",
        "dose": "4-8g"
      },
      {
        "name": "Kim ngân hoa",
        "dose": "12-20g"
      },
      {
        "name": "Liên kiều",
        "dose": "8g"
      },
      {
        "name": "Hoàng liên",
        "dose": "4g"
      },
      {
        "name": "Mạch môn",
        "dose": "12g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia làm 3 lần; Sừng tê giác mài uống riêng hoặc thay bằng sừng trâu liều cao",
    "analysis": "Sừng tê giác, Sinh địa (Quân) thanh nhiệt giải độc, lương huyết; Huyền sâm, Đan sâm, Mạch môn (Thần) dưỡng âm sinh tân, ngăn ngừa nhiệt làm hao tổn âm dịch; Kim ngân hoa, Liên kiều, Hoàng liên, Trúc diệp (Tá) trợ giúp thanh nhiệt tả hỏa ở phần khí",
    "contra": "",
    "note": ""
  },
  {
    "id": "thanh_hao_miet_giap_thang",
    "name": "Thanh hao miết giáp thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt hư nhiệt",
    "symptoms": [
      "Sốt về chiều hoặc sốt âm ỉ kéo dài",
      "lưỡi đỏ rêu ít",
      "miệng khô",
      "môi khô",
      "mồ hôi trộm"
    ],
    "effects": [
      "dưỡng âm",
      "sinh tân lương huyết",
      "thanh nhiệt"
    ],
    "indication": "thời kỳ hồi phục của bệnh truyền nhiễm có sốt âm ỉ kéo dài về chiều",
    "herbs": [
      {
        "name": "Thanh hao",
        "dose": "8-16g"
      },
      {
        "name": "Miết giáp",
        "dose": "8-16g"
      },
      {
        "name": "Sinh địa",
        "dose": "16-20g"
      },
      {
        "name": "Tri mẫu",
        "dose": "8-16g"
      },
      {
        "name": "Đan bì",
        "dose": "8-12g"
      }
    ],
    "usage": "Mỗi ngày 1 thang, sắc uống chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thanh_vi_tan",
    "name": "Thanh vị tán",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở tạng phủ",
    "symptoms": [
      "Răng lợi sưng loét",
      "đau bốc lên đầu",
      "phát sốt",
      "hôi miệng",
      "chảy máu chân răng",
      "môi lưỡi nổi mụn đau"
    ],
    "effects": [
      "thanh vị",
      "lương huyết"
    ],
    "indication": "thanh vị, lương huyết. Bài thuốc điều trị chứng vị hỏa thượng viêm gây đau sưng lợi, chảy máu chân răng",
    "herbs": [
      {
        "name": "Hoàng liên",
        "dose": "12g"
      },
      {
        "name": "Đương quy",
        "dose": "6g"
      },
      {
        "name": "Sinh địa",
        "dose": "6g"
      },
      {
        "name": "Đan bì",
        "dose": "10g"
      },
      {
        "name": "Thăng ma",
        "dose": "16g"
      }
    ],
    "usage": "Dạng bột mỗi lần uống 6 - 12g với nước mát; hoặc sắc uống ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "truc_diep_thach_cao_thang",
    "name": "Trúc diệp thạch cao thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt ở phần khí Thanh nhiệt tả hỏa",
    "symptoms": [
      "Sốt nhẹ",
      "khát nước nhiều",
      "buồn nôn",
      "chất lưỡi đỏ",
      "môi khô",
      "miệng hơi hôi"
    ],
    "effects": [
      "thanh khí nhiệt",
      "ích khí",
      "dưỡng âm",
      "giáng nghịch",
      "chỉ ẩu"
    ],
    "indication": "trường hợp nhiệt tà xâm phạm khí phận gây tổn thương âm dịch dẫn đến sốt nhẹ, miệng khô",
    "herbs": [
      {
        "name": "Trúc diệp",
        "dose": "12g"
      },
      {
        "name": "Thạch cao",
        "dose": "40g"
      },
      {
        "name": "Ngạnh mễ",
        "dose": "20g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "12g"
      },
      {
        "name": "Nhân sâm",
        "dose": "6g"
      },
      {
        "name": "Mạch môn",
        "dose": "20g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      }
    ],
    "usage": "Sắc uống, mỗi ngày uống 1 thang chia 3 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_dieu_dung_an_thang",
    "name": "Tứ diệu dũng an thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt giải độc",
    "symptoms": [
      "Chân sưng nóng đỏ đau",
      "có nước vàng chảy ra",
      "phát sốt",
      "miệng khát (bệnh viêm động mạch chi dưới)"
    ],
    "effects": [
      "thanh nhiệt giải độc",
      "hoạt huyết",
      "dưỡng âm"
    ],
    "indication": "thanh nhiệt giải độc, hoạt huyết, dưỡng âm. Bài thuốc được chỉ định cho chứng thoát thư (viêm động mạch chi dưới)",
    "herbs": [
      {
        "name": "Huyền sâm",
        "dose": "100g"
      },
      {
        "name": "Đương quy",
        "dose": "70g"
      },
      {
        "name": "Kim ngân hoa",
        "dose": "100g"
      },
      {
        "name": "Cam thảo",
        "dose": "30g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 3-4 lần uống trong ngày",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "uong_quy_luc_hoang_thang",
    "name": "Đương quy lục hoàng thang",
    "chapterNumber": 3,
    "chapterTitle": "Bài thuốc thanh nhiệt",
    "group": "Thanh nhiệt",
    "subgroup": "Thanh nhiệt hư nhiệt",
    "symptoms": [
      "Mồ hôi trộm (đạo hãn)",
      "miệng khô tâm phiền",
      "lưỡi đỏ",
      "mạch huyền sác"
    ],
    "effects": [
      "tả hỏa tư âm",
      "bổ khí huyết",
      "chỉ đạo hãn"
    ],
    "indication": "tả hỏa tư âm, bổ khí huyết, chỉ đạo hãn. Bài thuốc trị chứng âm hư hỏa vượng gây mồ hôi trộm, miệng khô tâm phiền",
    "herbs": [
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Sinh địa",
        "dose": "12g"
      },
      {
        "name": "Thục địa",
        "dose": "12g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "12g"
      },
      {
        "name": "Hoàng liên",
        "dose": "12g"
      },
      {
        "name": "Hoàng bá",
        "dose": "12g"
      },
      {
        "name": "Hoàng kỳ",
        "dose": "24g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ban_ha_ta_tam_thang",
    "name": "Bán hạ tả tâm thang",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải vị trường",
    "symptoms": [
      "Vùng thượng vị có khối cứng nhưng không đau",
      "bụng sôi đi ngoài phân lỏng",
      "buồn nôn",
      "nôn",
      "không muốn ăn"
    ],
    "effects": [
      "hòa vị giáng nghịch",
      "khai kết tán tích"
    ],
    "indication": "chứng hàn nhiệt thác tạp ở vị trường gây đầy chướng vùng thượng vị",
    "herbs": [
      {
        "name": "Bán hạ chế",
        "dose": "12g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "9g"
      },
      {
        "name": "Can khương",
        "dose": "9g"
      },
      {
        "name": "Nhân sâm",
        "dose": "9g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "9g"
      },
      {
        "name": "Hoàng liên",
        "dose": "3g"
      },
      {
        "name": "Đại táo",
        "dose": "12 quả"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "Bán hạ, Can khương (Quân) tân khai trừ bĩ; Hoàng liên, Hoàng cầm (Thần) khổ giáng thanh nhiệt",
    "contra": "",
    "note": ""
  },
  {
    "id": "ha_nhan_am",
    "name": "Hà nhân ẩm",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải chữa sốt rét",
    "symptoms": [
      "Sốt rét cơn kéo dài",
      "tái phát",
      "sắc mặt xanh nhợt",
      "người mệt mỏi",
      "khí huyết hư"
    ],
    "effects": [
      "bổ khí huyết",
      "trị hư ngược"
    ],
    "indication": "bổ khí huyết, trị hư ngược. Bài thuốc trị sốt rét lâu ngày gây khí huyết hư tổn",
    "herbs": [
      {
        "name": "Hà thủ ô",
        "dose": "20g"
      },
      {
        "name": "Nhân sâm",
        "dose": "4g"
      },
      {
        "name": "Đương quy",
        "dose": "8g"
      },
      {
        "name": "Trần bì",
        "dose": "8g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      }
    ],
    "usage": "Sắc uống, uống trước khi lên cơn sốt rét 2 giờ",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoang_lien_thang",
    "name": "Hoàng liên thang",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải vị trường",
    "symptoms": [
      "Trong bụng đau",
      "buồn nôn hoặc nôn mửa",
      "bụng sôi",
      "đi ngoài phân lỏng"
    ],
    "effects": [
      "điều hòa hàn nhiệt",
      "hòa vị giáng nghịch"
    ],
    "indication": "điều hòa hàn nhiệt, hòa vị giáng nghịch. Bài thuốc trị chứng trong ngực có nhiệt, trong vị có hàn gây buồn nôn, đau bụng",
    "herbs": [
      {
        "name": "Hoàng liên",
        "dose": "4-6g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "8-12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      },
      {
        "name": "Nhân sâm (Đảng sâm)",
        "dose": "8-16g"
      },
      {
        "name": "Can khương",
        "dose": "4-8g"
      },
      {
        "name": "Quế chi (Nhục quế)",
        "dose": "4-12g"
      },
      {
        "name": "Đại táo",
        "dose": "4-6 quả"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "sai_ho_so_can_thang",
    "name": "Sài hồ sơ can thang",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải can - tỳ",
    "symptoms": [
      "Đau tức mạng sườn",
      "hay cáu gắt",
      "đau đầu",
      "hoa mắt",
      "ăn kém"
    ],
    "effects": [
      "sơ can",
      "lý khí",
      "hòa huyết",
      "chỉ thống"
    ],
    "indication": "sơ can, lý khí, hòa huyết, chỉ thống. Bài thuốc điều trị chứng can khí uất kết kèm có huyết trệ gây đau tức mạng sườn",
    "herbs": [
      {
        "name": "Sài hồ",
        "dose": ""
      },
      {
        "name": "Bạch thược",
        "dose": ""
      },
      {
        "name": "Chỉ xác",
        "dose": ""
      },
      {
        "name": "Cam thảo (theo bài Tứ nghịch tán) gia thêm Xuyên khung",
        "dose": "8g"
      },
      {
        "name": "Hương phụ",
        "dose": "8g"
      },
      {
        "name": "Trần bì",
        "dose": "8g"
      }
    ],
    "usage": "Làm thang sắc uống, ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thong_ta_yeu_phuong",
    "name": "Thống tả yếu phương",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải can - tỳ",
    "symptoms": [
      "Đau bụng",
      "sôi bụng",
      "đau bụng thì đi ngoài",
      "đi ngoài xong thì hết đau"
    ],
    "effects": [
      "tiết can",
      "kiện tỳ"
    ],
    "indication": "tiết can, kiện tỳ. Bài thuốc điều trị chứng đau bụng sôi bụng, đi ngoài phân lỏng",
    "herbs": [
      {
        "name": "Bạch truật (sao vàng hạ thổ)",
        "dose": "120g"
      },
      {
        "name": "Trần bì (sao)",
        "dose": "60g"
      },
      {
        "name": "Phòng phong",
        "dose": "80g"
      },
      {
        "name": "Bạch thược (sao)",
        "dose": "80g"
      }
    ],
    "usage": "Dạng bột/hoàn uống 10g/lần, ngày 2 lần. Dạng sắc uống ngày 1 thang chia 2 lần",
    "analysis": "Bạch truật (Quân) kiện tỳ; Bạch thược (Thần) bình can; Trần bì (Tá) lý khí; Phòng phong (Sứ) dẫn thuốc vào can tỳ",
    "contra": "",
    "note": ""
  },
  {
    "id": "tiet_nguoc_that_bao_am",
    "name": "Tiệt ngược thất bảo ẩm",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải chữa sốt rét",
    "symptoms": [
      "Sốt rét cơn kéo dài",
      "cơ thể đàm thấp nặng",
      "rêu lưỡi trắng nhờn"
    ],
    "effects": [
      "tảo thấp",
      "trừ đàm"
    ],
    "indication": "tảo thấp, trừ đàm. Bài thuốc điều trị chứng sốt rét kéo dài do đàm thấp",
    "herbs": [
      {
        "name": "Thường sơn",
        "dose": "8g"
      },
      {
        "name": "Hậu phác",
        "dose": "4g"
      },
      {
        "name": "Thanh bì",
        "dose": "4g"
      },
      {
        "name": "Trần bì",
        "dose": "4g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      },
      {
        "name": "Binh lang",
        "dose": "4g"
      },
      {
        "name": "Thảo quả nhân",
        "dose": "4g"
      }
    ],
    "usage": "Sắc gia thêm ít rượu, uống trước 2 giờ khi lên cơn sốt rét",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_dao_tan",
    "name": "Tiêu dao tán",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải can - tỳ",
    "symptoms": [
      "Đau tức 2 bên mạng sườn",
      "mệt mỏi",
      "kém ăn",
      "miệng khô",
      "phụ nữ rối loạn kinh nguyệt"
    ],
    "effects": [
      "sơ can giải uất",
      "kiện tỳ dưỡng huyết"
    ],
    "indication": "chứng can uất huyết hư gây mệt mỏi, kém ăn, kinh nguyệt không đều",
    "herbs": [
      {
        "name": "Sài hồ",
        "dose": "8-12g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4-6g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      },
      {
        "name": "Sinh khương",
        "dose": "4g"
      },
      {
        "name": "Bạc hà",
        "dose": "4g"
      }
    ],
    "usage": "Dạng bột uống 10g/lần, ngày 2 lần. Dạng sắc uống ngày 1 thang chia 2 lần",
    "analysis": "Sài hồ (Quân) sơ can giải uất; Đương quy, Bạch thược (Thần) dưỡng huyết nhuận can; Bạch truật, Phục linh (Tá) kiện tỳ; Cam thảo, Sinh khương, Bạc hà (Sứ) hỗ trợ tán uất và điều hòa bài thuốc",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_sai_ho_thang",
    "name": "Tiểu sài hồ thang",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải chứng bệnh thiếu dương",
    "symptoms": [
      "Hàn nhiệt vãng lai (sốt rét lúc nóng lúc lạnh)",
      "ngực sườn đầy tức",
      "ăn kém",
      "hồi hộp",
      "nôn mửa",
      "miệng đắng",
      "họng khô"
    ],
    "effects": [
      "hòa giải thiếu dương",
      "phù chính trừ tà"
    ],
    "indication": "hòa giải thiếu dương, phù chính trừ tà. Bài thuốc trị chứng thiếu dương bệnh có triệu chứng lúc nóng lúc lạnh, ngực sườn đầy tức",
    "herbs": [
      {
        "name": "Sài hồ",
        "dose": "24g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "9g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "9g"
      },
      {
        "name": "Nhân sâm (Đảng sâm)",
        "dose": "9g (có tài liệu ghi 20g)"
      },
      {
        "name": "Chích cam thảo",
        "dose": "6g"
      },
      {
        "name": "Sinh khương",
        "dose": "9g"
      },
      {
        "name": "Đại táo",
        "dose": "12 quả"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Sài hồ (Quân) sơ tà giải nhiệt, thông lợi uất kết; Hoàng cầm (Thần) thanh nhiệt ở can đởm; Bán hạ, Sinh khương (Tá) hòa vị giáng nghịch chỉ nôn; Nhân sâm, Cam thảo (Tá) phù chính; Đại táo (Sứ) điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_nghich_tan",
    "name": "Tứ nghịch tán",
    "chapterNumber": 4,
    "chapterTitle": "Bài thuốc hòa giải",
    "group": "Hòa giải",
    "subgroup": "Hòa giải can - tỳ",
    "symptoms": [
      "Đau ngực sườn và bụng đau",
      "tay chân không ấm",
      "hoặc hơi sốt",
      "ho",
      "tim đập mạnh"
    ],
    "effects": [
      "sơ can",
      "lý tỳ",
      "thấu tà",
      "giải uất"
    ],
    "indication": "trường hợp can khí uất kết gây đau ngực sườn, tay chân không ấm",
    "herbs": [
      {
        "name": "Sài hồ",
        "dose": "4-12g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Chỉ thực",
        "dose": "6-12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-6g"
      }
    ],
    "usage": "Dạng bột uống 10g/lần, ngày 2 lần. Dạng sắc uống ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "chan_vu_thang",
    "name": "Chân vũ thang",
    "chapterNumber": 5,
    "chapterTitle": "Bài thuốc ôn lý trừ hàn (Ôn tễ)",
    "group": "Ôn lý trừ hàn (Ôn tễ)",
    "subgroup": "Hồi dương cứu nghịch",
    "symptoms": [
      "Phù chi dưới hoặc toàn thân",
      "đi tiểu ít",
      "tay chân nặng nề",
      "sợ lạnh",
      "đau bụng",
      "đi ngoài lỏng"
    ],
    "effects": [
      "ôn thận",
      "tán hàn",
      "kiện tỳ",
      "lợi thủy"
    ],
    "indication": "ôn thận, tán hàn, kiện tỳ, lợi thủy. Bài thuốc trị chứng thuỷ thũng do thận dương hư",
    "herbs": [
      {
        "name": "Phục linh",
        "dose": "12-16g"
      },
      {
        "name": "Bạch thược",
        "dose": "12-16g"
      },
      {
        "name": "Bạch truật",
        "dose": "8-12g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "8-12g"
      },
      {
        "name": "Sinh khương",
        "dose": "8-12g"
      }
    ],
    "usage": "Làm thang sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Phụ tử chế (Quân) ôn thận dương để hóa khí lợi thủy; Phục linh, Bạch truật (Thần) kiện tỳ lợi thủy; Bạch thược (Sứ) liễm âm, hòa dinh và chỉ thống; Sinh khương hỗ trợ thông dương",
    "contra": "",
    "note": ""
  },
  {
    "id": "ly_trung_thang",
    "name": "Lý trung thang",
    "chapterNumber": 5,
    "chapterTitle": "Bài thuốc ôn lý trừ hàn (Ôn tễ)",
    "group": "Ôn lý trừ hàn (Ôn tễ)",
    "subgroup": "Ôn trung trừ hàn",
    "symptoms": [
      "Đau bụng",
      "đại tiện lỏng nát",
      "nôn mửa",
      "ăn kém",
      "miệng không khát",
      "chân tay lạnh"
    ],
    "effects": [
      "ôn trung",
      "trừ hàn",
      "kiện tỳ",
      "bổ khí"
    ],
    "indication": "chứng tỳ vị hư hàn gây đau bụng, đi ngoài lỏng",
    "herbs": [
      {
        "name": "Nhân sâm (Đảng sâm)",
        "dose": "8-16g"
      },
      {
        "name": "Bạch truật",
        "dose": "8-16g"
      },
      {
        "name": "Can khương",
        "dose": "4-8g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4-8g"
      }
    ],
    "usage": "Có thể làm hoàn mật; nếu sắc uống thì ngày 1 thang chia 2 lần",
    "analysis": "Can khương (Quân) tính nóng để trừ hàn, ôn ấm trung tiêu; Nhân sâm (Thần) đại bổ nguyên khí; Bạch truật (Tá) kiện tỳ táo thấp; Cam thảo (Sứ) điều hòa và trợ tỳ",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngo_thu_du_thang",
    "name": "Ngô thù du thang",
    "chapterNumber": 5,
    "chapterTitle": "Bài thuốc ôn lý trừ hàn (Ôn tễ)",
    "group": "Ôn lý trừ hàn (Ôn tễ)",
    "subgroup": "Ôn trung trừ hàn",
    "symptoms": [
      "Nôn buồn nôn sau khi ăn",
      "nuốt chua",
      "đau vùng thượng vị",
      "hoặc nôn khan ra nước dãi",
      "đau đỉnh đầu"
    ],
    "effects": [
      "ôn trung bổ hư",
      "giáng nghịch",
      "chỉ ẩu"
    ],
    "indication": "chứng hư hàn ở vị gây nôn mửa sau khi ăn, đau đỉnh đầu",
    "herbs": [
      {
        "name": "Ngô thù du",
        "dose": "4-8g"
      },
      {
        "name": "Nhân sâm (Đảng sâm)",
        "dose": "12-16g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Đại táo",
        "dose": "4-6 quả"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "sam_phu_thang",
    "name": "Sâm phụ thang",
    "chapterNumber": 5,
    "chapterTitle": "Bài thuốc ôn lý trừ hàn (Ôn tễ)",
    "group": "Ôn lý trừ hàn (Ôn tễ)",
    "subgroup": "Hồi dương cứu nghịch",
    "symptoms": [
      "Dương khí suy sụp",
      "người lạnh",
      "mồ hôi ra nhiều",
      "váng đầu",
      "sắc mặt nhợt",
      "mạch vi muốn tuyệt"
    ],
    "effects": [
      "hồi dương",
      "ích khí",
      "cố thoát"
    ],
    "indication": "hồi dương, ích khí, cố thoát. Bài thuốc dùng trong trường hợp dương khí hoạt thoát dẫn đến mồ hôi ra nhiều, người lạnh",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "8-16g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "8-12g"
      }
    ],
    "usage": "Sắc uống và uống nóng; trường hợp nặng có thể uống 2 thang/ngày",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_kien_trung_thang",
    "name": "Tiểu kiến trung thang",
    "chapterNumber": 5,
    "chapterTitle": "Bài thuốc ôn lý trừ hàn (Ôn tễ)",
    "group": "Ôn lý trừ hàn (Ôn tễ)",
    "subgroup": "Ôn trung trừ hàn",
    "symptoms": [
      "Đau bụng vùng thượng vị",
      "xoa ấm thì giảm",
      "hồi hộp",
      "hư phiền không yên"
    ],
    "effects": [
      "ôn dưỡng tỳ vị",
      "thông dương khí",
      "hòa dinh huyết"
    ],
    "indication": "ôn dưỡng tỳ vị, thông dương khí, hòa dinh huyết. Bài thuốc trị chứng tỳ vị hư hàn gây đau bụng âm ỉ, thích xoa ấm",
    "herbs": [
      {
        "name": "Quế chi",
        "dose": "8g"
      },
      {
        "name": "Bạch thược",
        "dose": "16g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Đại táo",
        "dose": "5 quả"
      },
      {
        "name": "Di đường",
        "dose": "35-70g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Bạch thược liều cao (Quân) chỉ thống; Di đường (Quân) ôn bổ trung tiêu; Quế chi (Thần) ôn dương; Cam thảo, Khương Táo điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_nghich_thang",
    "name": "Tứ nghịch thang",
    "chapterNumber": 5,
    "chapterTitle": "Bài thuốc ôn lý trừ hàn (Ôn tễ)",
    "group": "Ôn lý trừ hàn (Ôn tễ)",
    "subgroup": "Hồi dương cứu nghịch",
    "symptoms": [
      "Tay chân lạnh (quyết nghịch)",
      "đi ngoài phân lỏng nát (phân sống)",
      "mồ hôi lạnh",
      "nôn mửa",
      "mạch vi muốn tuyệt"
    ],
    "effects": [
      "hồi dương cứu nghịch"
    ],
    "indication": "hồi dương cứu nghịch. Bài thuốc được chỉ định khi âm hàn thịnh ở bên trong gây tay chân lạnh, mạch vi muốn tuyệt",
    "herbs": [
      {
        "name": "Sinh phụ tử",
        "dose": "15g"
      },
      {
        "name": "Can khương",
        "dose": "9g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "6g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "Phụ tử (Quân) tính cay nóng mãnh liệt để hồi dương cứu nghịch; Can khương (Thần) giúp Phụ tử ôn dương tán hàn hiệu quả hơn; Cam thảo (Tá, Sứ) làm hoãn tính nóng của các vị thuốc và điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "linh_duong_cau_ang_thang",
    "name": "Linh dương câu đằng thang",
    "chapterNumber": 6,
    "chapterTitle": "Bài thuốc trừ phong",
    "group": "Trừ phong",
    "subgroup": "Bình can tức phong",
    "symptoms": [
      "Sốt cao",
      "co giật",
      "hôn mê",
      "nói sảng do bệnh ôn nhiệt"
    ],
    "effects": [
      "lương can tức phong",
      "tăng dịch thư cân"
    ],
    "indication": "lương can tức phong, tăng dịch thư cân. Bài thuốc trị bệnh ngoại cảm ôn nhiệt vào kinh can gây sốt cao co giật",
    "herbs": [
      {
        "name": "Linh dương giác",
        "dose": "4g"
      },
      {
        "name": "Tang diệp",
        "dose": "12g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Phục thần",
        "dose": "12g"
      },
      {
        "name": "Xuyên bối mẫu",
        "dose": "8g"
      },
      {
        "name": "Sinh địa",
        "dose": "16g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Câu đằng",
        "dose": "12g"
      },
      {
        "name": "Cúc hoa",
        "dose": "12g"
      },
      {
        "name": "Trúc nhự",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "oc_hoat_tang_ky_sinh_thang",
    "name": "Độc hoạt tang ký sinh thang",
    "chapterNumber": 6,
    "chapterTitle": "Bài thuốc trừ phong",
    "group": "Trừ phong",
    "subgroup": "Trừ phong thấp",
    "symptoms": [
      "Đau các khớp xương",
      "lưng gối đau mỏi",
      "phong thấp lâu ngày cơ thể suy nhược"
    ],
    "effects": [
      "trừ phong thấp",
      "bổ khí huyết",
      "ích can thận"
    ],
    "indication": "phong thấp lâu ngày gây đau lưng mỏi gối, cơ thể suy nhược",
    "herbs": [
      {
        "name": "Độc hoạt",
        "dose": "12g"
      },
      {
        "name": "Tang ký sinh",
        "dose": "16-50g"
      },
      {
        "name": "Tần giao",
        "dose": "12g"
      },
      {
        "name": "Phòng phong",
        "dose": "12g"
      },
      {
        "name": "Đỗ trọng",
        "dose": "12g"
      },
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Tế tân",
        "dose": "4-8g"
      },
      {
        "name": "Ngưu tất",
        "dose": "12g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Quế chi",
        "dose": "6g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4-12g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Xích thược",
        "dose": "12g"
      },
      {
        "name": "Xuyên khung",
        "dose": "8-12g"
      },
      {
        "name": "Địa hoàng",
        "dose": "16-24g"
      },
      {
        "name": "Can địa hoàng",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Độc hoạt (Quân) khu phong trừ thấp ở hạ tiêu; Tang ký sinh, Đỗ trọng, Ngưu tất hỗ trợ bổ can thận, mạnh gân xương; các vị còn lại như Đương quy, Địa hoàng giúp dưỡng huyết (vì \"trị phong tiên trị huyết\")",
    "contra": "",
    "note": ""
  },
  {
    "id": "que_chi_thuoc_duoc_tri_mau_thang",
    "name": "Quế chi thược dược tri mẫu thang",
    "chapterNumber": 6,
    "chapterTitle": "Bài thuốc trừ phong",
    "group": "Trừ phong",
    "subgroup": "Trừ phong thấp",
    "symptoms": [
      "Các khớp sưng đau sợ nóng nhưng toàn thân phát sốt không rõ",
      "sợ lạnh"
    ],
    "effects": [
      "thông dương hành tý",
      "khu phong trừ thấp"
    ],
    "indication": "giai đoạn phong hàn thấp tý chuyển sang hóa nhiệt",
    "herbs": [
      {
        "name": "Quế chi",
        "dose": "8-12g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "8g"
      },
      {
        "name": "Ma hoàng",
        "dose": "8g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      },
      {
        "name": "Tri mẫu",
        "dose": "12g"
      },
      {
        "name": "Phòng phong",
        "dose": "12g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "8-12g"
      },
      {
        "name": "Sinh khương",
        "dose": "3-5 lát"
      }
    ],
    "usage": "Sắc uống ngày 1 thang chia 2 lần; hoặc tán bột uống 12g/lần, ngày 2 lần vào sáng và tối",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "quyen_ty_thang",
    "name": "Quyên tý thang",
    "chapterNumber": 6,
    "chapterTitle": "Bài thuốc trừ phong",
    "group": "Trừ phong",
    "subgroup": "Trừ phong thấp",
    "symptoms": [
      "Tay chân và các khớp đau nhức",
      "cảm giác nặng nề",
      "tê dại",
      "đau tăng khi gặp lạnh"
    ],
    "effects": [
      "trừ phong thấp",
      "chỉ thống"
    ],
    "indication": "trừ phong thấp, chỉ thống. Bài thuốc trị chứng phong hàn thấp tý gây đau nhức khớp xương, tê dại",
    "herbs": [
      {
        "name": "Khương hoạt",
        "dose": "12g"
      },
      {
        "name": "Độc hoạt",
        "dose": "12g"
      },
      {
        "name": "Quế chi",
        "dose": "8-12g"
      },
      {
        "name": "Nhũ hương",
        "dose": "4-8g"
      },
      {
        "name": "Tần giao",
        "dose": "12g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Xuyên khung",
        "dose": "8-12g"
      },
      {
        "name": "Bắc mộc hương",
        "dose": "6-12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      },
      {
        "name": "Hải phong đằng",
        "dose": "30g"
      },
      {
        "name": "Tang chi",
        "dose": "30g"
      }
    ],
    "usage": "Mỗi ngày 1 thang, sắc uống chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thien_ma_cau_ang_am",
    "name": "Thiên ma câu đằng ẩm",
    "chapterNumber": 6,
    "chapterTitle": "Bài thuốc trừ phong",
    "group": "Trừ phong",
    "subgroup": "Bình can tức phong",
    "symptoms": [
      "Hoa mắt",
      "chóng mặt",
      "đau đầu",
      "nặng đầu mất ngủ do cao huyết áp"
    ],
    "effects": [
      "bình can",
      "tức phong"
    ],
    "indication": "bình can, tức phong. Bài thuốc điều trị cao huyết áp gây đau đầu, hoa mắt, chóng mặt, mất ngủ",
    "herbs": [
      {
        "name": "Thiên ma",
        "dose": "8g"
      },
      {
        "name": "Câu đằng",
        "dose": "16g"
      },
      {
        "name": "Sinh thạch quyết minh",
        "dose": "20g"
      },
      {
        "name": "Phục thần",
        "dose": "16g"
      },
      {
        "name": "Tang ký sinh",
        "dose": "12g"
      },
      {
        "name": "Đỗ trọng",
        "dose": "16g"
      },
      {
        "name": "Ngưu tất",
        "dose": "12g"
      },
      {
        "name": "Dạ giao đằng",
        "dose": "20g"
      },
      {
        "name": "Chi tử",
        "dose": "12g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "12g"
      },
      {
        "name": "Ích mẫu",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Thiên ma, Câu đằng, Thạch quyết minh (Quân) bình can tức phong",
    "contra": "",
    "note": ""
  },
  {
    "id": "tran_can_tuc_phong_thang",
    "name": "Trấn can tức phong thang",
    "chapterNumber": 6,
    "chapterTitle": "Bài thuốc trừ phong",
    "group": "Trừ phong",
    "subgroup": "Bình can tức phong",
    "symptoms": [
      "Đau đầu",
      "chóng mặt",
      "hoa mắt",
      "tai ù",
      "tay chân co giật",
      "miệng méo",
      "sắc mặt đỏ"
    ],
    "effects": [
      "trấn can tức phong",
      "tư âm",
      "tiềm dương"
    ],
    "indication": "trấn can tức phong, tư âm, tiềm dương. Bài thuốc trị chứng can dương thượng cang, can phong nội động gây đau đầu, co giật",
    "herbs": [
      {
        "name": "Ngưu tất",
        "dose": "30g"
      },
      {
        "name": "Sinh long cốt",
        "dose": "20g"
      },
      {
        "name": "Qui bản",
        "dose": "20g"
      },
      {
        "name": "Huyền sâm",
        "dose": "20g"
      },
      {
        "name": "Sinh giả thạch",
        "dose": "30g"
      },
      {
        "name": "Sinh mẫu lệ",
        "dose": "20g"
      },
      {
        "name": "Bạch thược",
        "dose": "20g"
      },
      {
        "name": "Mạch môn",
        "dose": "20g"
      },
      {
        "name": "Xuyên luyện tử",
        "dose": "8g"
      },
      {
        "name": "Mạch nha",
        "dose": "8g"
      },
      {
        "name": "Thanh hao",
        "dose": "8g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Ngưu tất (Quân) dẫn huyết hạ hành, làm giảm áp lực phía trên; Giả thạch, Long cốt, Mẫu lệ (Thần) trấn kinh tiềm dương; Huyền sâm, Thiên môn, Bạch thược tư âm dưỡng dịch; Sơ can nhờ Xuyên luyện tử, Mạch nha",
    "contra": "",
    "note": ""
  },
  {
    "id": "bat_chinh_tan",
    "name": "Bát chính tán",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Thanh nhiệt thông lâm",
    "symptoms": [
      "Đi tiểu buốt",
      "tiểu rắt",
      "tiểu đỏ hoặc ra máu",
      "bụng dưới đau"
    ],
    "effects": [
      "thanh nhiệt",
      "tả hỏa",
      "lợi thủy",
      "thông lâm"
    ],
    "indication": "thanh nhiệt, tả hỏa, lợi thủy, thông lâm. Bài thuốc trị chứng thấp nhiệt ở bàng quang gây tiểu buốt, tiểu rắt",
    "herbs": [
      {
        "name": "Xa tiền tử",
        "dose": "12-20g"
      },
      {
        "name": "Mộc thông",
        "dose": "4-8g"
      },
      {
        "name": "Cù mạch",
        "dose": "12g"
      },
      {
        "name": "Biển súc",
        "dose": "12g"
      },
      {
        "name": "Hoạt thạch",
        "dose": "20-30g"
      },
      {
        "name": "Cam thảo",
        "dose": "4-12g"
      },
      {
        "name": "Chi tử",
        "dose": "8-12g"
      },
      {
        "name": "Chế đại hoàng",
        "dose": "8-12g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Mộc thông, Xa tiền tử, Cù mạch, Biển súc, Hoạt thạch (Quân) phối hợp lợi thủy thông lâm; Chi tử, Đại hoàng (Thần) thanh hỏa tả nhiệt, dẫn nhiệt xuống dưới; Cam thảo điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "binh_vi_tan",
    "name": "Bình vị tán",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Táo thấp kiện tỳ",
    "symptoms": [
      "Ngực bụng đầy trướng",
      "ăn không ngon",
      "buồn nôn",
      "chân tay mỏi mệt",
      "đại tiện nhão"
    ],
    "effects": [
      "táo thấp",
      "hành khí kiện tỳ hòa vị"
    ],
    "indication": "táo thấp, hành khí kiện tỳ hòa vị. Bài thuốc điều trị chứng thấp trở tỳ vị gây đầy bụng, ăn không ngon",
    "herbs": [
      {
        "name": "Thương thuật",
        "dose": "6-12g"
      },
      {
        "name": "Hậu phác",
        "dose": "4-12g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Trần bì",
        "dose": "6-12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Đại táo",
        "dose": "3 quả"
      }
    ],
    "usage": "Thường dùng dạng sắc ngày 1 thang chia 2 lần",
    "analysis": "Thương thuật (Quân) táo thấp; Hậu phác (Thần) hành khí; Trần bì (Tá) lý khí; Cam thảo, Khương Táo (Sứ) điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoac_huong_chinh_khi_tan",
    "name": "Hoắc hương chính khí tán",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Phương hương hóa thấp",
    "symptoms": [
      "Sợ lạnh",
      "phát sốt",
      "đau đầu",
      "ngực bụng đầy trướng",
      "buồn nôn",
      "tiêu chảy",
      "rêu lưỡi trắng nhờn"
    ],
    "effects": [
      "phương hương hóa thấp",
      "lý khí",
      "hòa trung"
    ],
    "indication": "phương hương hóa thấp, lý khí, hòa trung. Bài thuốc trị chứng thử thấp hoặc cảm mạo gây nôn mửa, tiêu chảy",
    "herbs": [
      {
        "name": "Hoắc hương",
        "dose": "12g"
      },
      {
        "name": "Tử tô",
        "dose": "8-12g"
      },
      {
        "name": "Bạch chỉ",
        "dose": "4-8g"
      },
      {
        "name": "Trần bì",
        "dose": "6-12g"
      },
      {
        "name": "Cát cánh",
        "dose": "4-8g"
      },
      {
        "name": "Bạch truật",
        "dose": "8-12g"
      },
      {
        "name": "Hậu phác",
        "dose": "4-8g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "12g"
      },
      {
        "name": "Đại phúc bì",
        "dose": "8-12g"
      },
      {
        "name": "Phục linh",
        "dose": "12-16g"
      }
    ],
    "usage": "Dạng bột/hoàn uống 8-12g/lần, ngày 2-3 lần. Dạng sắc uống ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "luc_nhat_tan",
    "name": "Lục nhất tán",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Thanh nhiệt thông lâm",
    "symptoms": [
      "Phát sốt",
      "tâm phiền",
      "miệng khát",
      "tiểu tiện khó khăn do cảm nắng"
    ],
    "effects": [
      "khử thử",
      "lợi thấp"
    ],
    "indication": "khử thử, lợi thấp. Bài thuốc dùng khi cảm thụ thử thấp gây sốt, tâm phiền, tiểu khó",
    "herbs": [
      {
        "name": "Hoạt thạch",
        "dose": "6 phần"
      },
      {
        "name": "Sinh cam thảo",
        "dose": "1 phần"
      }
    ],
    "usage": "Tán bột uống 12-30g/lần với nước ấm; khi cho vào thang sắc cần bao trong túi giấy",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngu_bi_am",
    "name": "Ngũ bì ẩm",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Thẩm thấp lợi thủy",
    "symptoms": [
      "Toàn thân phù thũng",
      "bụng đầy chướng",
      "tiểu tiện ít"
    ],
    "effects": [
      "lý khí",
      "kiện tỳ",
      "hoá thấp",
      "lợi thuỷ"
    ],
    "indication": "chứng toàn thân phù thũng, bụng đầy chướng",
    "herbs": [
      {
        "name": "Tang bạch bì",
        "dose": "16g"
      },
      {
        "name": "Trần bì",
        "dose": "8g"
      },
      {
        "name": "Sinh khương bì",
        "dose": "12g"
      },
      {
        "name": "Đại phúc bì",
        "dose": "8g"
      },
      {
        "name": "Phục linh bì",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngu_linh_tan",
    "name": "Ngũ linh tán",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Thẩm thấp lợi thủy",
    "symptoms": [
      "Đi tiểu ít",
      "phù thũng",
      "bồn chồn khát nước nhưng uống vào lại nôn ra"
    ],
    "effects": [
      "thông dương",
      "hóa khí",
      "lợi thủy",
      "thẩm thấp"
    ],
    "indication": "thông dương, hóa khí, lợi thủy, thẩm thấp. Bài thuốc trị chứng thuỷ thấp đình ngưng gây tiểu ít, phù thũng",
    "herbs": [
      {
        "name": "Bạch truật",
        "dose": "8g"
      },
      {
        "name": "Quế chi (Nhục quế)",
        "dose": "4g"
      },
      {
        "name": "Trư linh",
        "dose": "12g"
      },
      {
        "name": "Trạch tả",
        "dose": "12g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      }
    ],
    "usage": "Dạng bột uống 8-12g/lần ngày 2 lần với nước ấm khi đói. Dạng sắc uống ngày 1 thang chia 2 lần",
    "analysis": "Trạch tả (Quân) tính lạnh lợi thủy thấm thấp; Trư linh, Phục linh (Thần) hỗ trợ lợi thấp; Bạch truật kiện tỳ; Quế chi (Sứ) giúp thông dương hóa khí để bàng quang bài tiết nước tiểu tốt hơn",
    "contra": "",
    "note": ""
  },
  {
    "id": "phong_ky_hoang_ky_thang",
    "name": "Phòng kỷ hoàng kỳ thang",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Thẩm thấp lợi thủy",
    "symptoms": [
      "Phù thũng",
      "sợ gió",
      "mồ hôi tự ra",
      "cơ thể nặng nề",
      "tiểu ít"
    ],
    "effects": [
      "bổ khí",
      "kiện tỳ",
      "lợi thuỷ"
    ],
    "indication": "bổ khí, kiện tỳ, lợi thuỷ. Bài thuốc trị chứng phong thuỷ gây phù thũng, sợ gió, mồ hôi tự ra",
    "herbs": [
      {
        "name": "Phòng kỷ",
        "dose": "12g"
      },
      {
        "name": "Hoàng kỳ",
        "dose": "12-30g"
      },
      {
        "name": "Bạch truật",
        "dose": "8-12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Đại táo",
        "dose": "3 quả"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tam_nhan_thang",
    "name": "Tam nhân thang",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Phương hương hóa thấp",
    "symptoms": [
      "Sốt âm ỉ",
      "đầu đau nặng",
      "ngực đầy tức",
      "không thích uống nước",
      "thân thể nặng nề"
    ],
    "effects": [
      "tuyên thông khí cơ",
      "thanh lợi thấp nhiệt"
    ],
    "indication": "chứng thấp nhiệt lưu ở khí phận",
    "herbs": [
      {
        "name": "Hạnh nhân",
        "dose": "12g"
      },
      {
        "name": "Bạch khấu nhân",
        "dose": "2-6g"
      },
      {
        "name": "Ý dĩ",
        "dose": "12-20g"
      },
      {
        "name": "Hậu phác",
        "dose": "4-8g"
      },
      {
        "name": "Thông thảo",
        "dose": "4g"
      },
      {
        "name": "Hoạt thạch",
        "dose": "12-20g"
      },
      {
        "name": "Trúc diệp",
        "dose": "4-12g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "6-12g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thuc_ty_am",
    "name": "Thực tỳ ẩm",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Thẩm thấp lợi thủy",
    "symptoms": [
      "Đi tiểu ít",
      "đại tiện nhão nát",
      "ngực bụng đầy trướng",
      "phù toàn thân"
    ],
    "effects": [
      "ôn dương",
      "kiện tỳ",
      "hành khí",
      "lợi thuỷ"
    ],
    "indication": "ôn dương, kiện tỳ, hành khí, lợi thuỷ. Bài thuốc trị chứng âm thủy (phù do tỳ dương hư)",
    "herbs": [
      {
        "name": "Bạch truật",
        "dose": "4-12g"
      },
      {
        "name": "Hậu phác",
        "dose": "4-8g"
      },
      {
        "name": "Binh lang",
        "dose": "4-12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      },
      {
        "name": "Thảo quả",
        "dose": "8-12g"
      },
      {
        "name": "Mộc hương",
        "dose": "4-8g"
      },
      {
        "name": "Mộc qua",
        "dose": "8-12g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Phụ tử chế",
        "dose": "4-12g"
      },
      {
        "name": "Can khương",
        "dose": "4-8g"
      },
      {
        "name": "Phục linh",
        "dose": "12-16g"
      },
      {
        "name": "Đại táo",
        "dose": "3 quả"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "Phụ tử, Can khương (Quân) ôn dương kiện tỳ; Phục linh, Bạch truật (Thần) lợi thủy; Hậu phác, Mộc hương, Binh lang, Thảo quả (Tá) hành khí",
    "contra": "",
    "note": ""
  },
  {
    "id": "ty_giai_phan_thanh_am",
    "name": "Tỳ giải phân thanh ẩm",
    "chapterNumber": 7,
    "chapterTitle": "Bài thuốc hóa thấp - lợi thủy",
    "group": "Hóa thấp - lợi thủy",
    "subgroup": "Thanh nhiệt thông lâm",
    "symptoms": [
      "Đi tiểu đục như nước vo gạo hoặc có váng mỡ"
    ],
    "effects": [
      "ôn thận hạ tiêu",
      "lợi thấp",
      "hóa trọc"
    ],
    "indication": "đi tiểu đục như nước vo gạo hoặc có váng mỡ",
    "herbs": [
      {
        "name": "Tỳ giải",
        "dose": "9g"
      },
      {
        "name": "Ô dược",
        "dose": "9g"
      },
      {
        "name": "Ích trí nhân",
        "dose": "9g"
      },
      {
        "name": "Thạch xương bồ",
        "dose": "9g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bach_hop_co_kim_thang",
    "name": "Bách hợp cố kim thang",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Nhuận táo hóa đàm",
    "symptoms": [
      "Ho khan hoặc ít đờm",
      "hầu họng khô đau",
      "mũi khô",
      "khó thở"
    ],
    "effects": [
      "thanh phế",
      "nhuận táo"
    ],
    "indication": "thanh phế, nhuận táo. Bài thuốc trị chứng táo nhiệt làm tổn thương phế gây ho khan, đờm ít",
    "herbs": [
      {
        "name": "Tang diệp",
        "dose": "12g"
      },
      {
        "name": "Thạch cao",
        "dose": "20-30g"
      },
      {
        "name": "Nhân sâm (Sa sâm)",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Ma nhân",
        "dose": "12g"
      },
      {
        "name": "A giao",
        "dose": "8-12g"
      },
      {
        "name": "Mạch môn",
        "dose": "12g"
      },
      {
        "name": "Trắc bá diệp",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ban_ha_bach_truat_thien_ma_thang",
    "name": "Bán hạ bạch truật thiên ma thang",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Trị phong hóa đàm",
    "symptoms": [
      "Chóng mặt (huyễn vựng)",
      "đau đầu",
      "buồn nôn",
      "nôn",
      "lồng ngực đầy chướng"
    ],
    "effects": [
      "kiện tỳ",
      "hóa thấp",
      "bình can",
      "tức phong"
    ],
    "indication": "chứng phong đàm gây chóng mặt, đau đầu",
    "herbs": [
      {
        "name": "Bán hạ chế",
        "dose": "8-12g"
      },
      {
        "name": "Quất hồng",
        "dose": "8-12g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Thiên ma",
        "dose": "12g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Đại táo",
        "dose": "4 quả"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "Bán hạ, Thiên ma (Quân) hóa đàm tức phong, chủ trị chóng mặt; Bạch truật, Phục linh (Thần) kiện tỳ trừ thấp; các vị khác điều hòa lý khí",
    "contra": "",
    "note": ""
  },
  {
    "id": "boi_mau_qua_lau_tan",
    "name": "Bối mẫu qua lâu tán",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Nhuận táo hóa đàm",
    "symptoms": [
      "Ho khạc đờm khó",
      "đờm khô rít",
      "họng khô"
    ],
    "effects": [
      "thanh nhiệt",
      "nhuận phế",
      "lý khí",
      "hóa đàm"
    ],
    "indication": "ho khạc đờm khó, đờm khô dính",
    "herbs": [
      {
        "name": "Bối mẫu",
        "dose": "6g"
      },
      {
        "name": "Phục linh",
        "dose": "3g"
      },
      {
        "name": "Qua lâu",
        "dose": "4g"
      },
      {
        "name": "Trần bì",
        "dose": "3g"
      },
      {
        "name": "Thiên hoa phấn",
        "dose": "3g"
      },
      {
        "name": "Cát cánh",
        "dose": "3g"
      }
    ],
    "usage": "Sắc uống",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "chi_thau_tan",
    "name": "Chỉ thấu tán",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Trị phong hóa đàm",
    "symptoms": [
      "Ho kéo dài không khỏi",
      "họng ngứa",
      "có thể kèm sợ lạnh"
    ],
    "effects": [
      "chỉ khái",
      "hoá đàm"
    ],
    "indication": "chỉ khái, hoá đàm. Bài thuốc điều trị chứng ho kéo dài do ngoại cảm phong tà vào phế",
    "herbs": [
      {
        "name": "Kinh giới",
        "dose": "8g"
      },
      {
        "name": "Cát cánh",
        "dose": "12g"
      },
      {
        "name": "Bạch tiền",
        "dose": "8g"
      },
      {
        "name": "Tử uyển",
        "dose": "12g"
      },
      {
        "name": "Bách bộ",
        "dose": "12g"
      },
      {
        "name": "Trần bì",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      }
    ],
    "usage": "Dạng bột uống 12g/lần; dạng sắc ngày 1 thang chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "kim_thuy_luc_quan_tien",
    "name": "Kim thủy lục quân tiễn",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Táo thấp hóa đàm",
    "symptoms": [
      "Ho",
      "khó thở",
      "đờm nhiều",
      "miệng họng khô ráo"
    ],
    "effects": [
      "dưỡng âm",
      "hoá đàm"
    ],
    "indication": "chứng phế thận âm hư sinh đàm gây ho, khó thở",
    "herbs": [
      {
        "name": "Bán hạ chế",
        "dose": "8-12g"
      },
      {
        "name": "Trần bì",
        "dose": "8-12g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Đương quy",
        "dose": "8g"
      },
      {
        "name": "Thục địa",
        "dose": "20g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần, gia thêm gừng và đại táo",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "linh_cam_ngu_vi_khuong_tan_thang",
    "name": "Linh cam ngũ vị khương tân thang",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Ôn hóa hàn đàm",
    "symptoms": [
      "Ho",
      "khạc đờm loãng trắng",
      "ngực đầy tức",
      "thích ngủ"
    ],
    "effects": [
      "ôn phế",
      "hoá đàm"
    ],
    "indication": "ôn phế, hoá đàm. Bài thuốc trị chứng hàn ẩm lưu ở phế gây ho khạc đờm loãng trắng",
    "herbs": [
      {
        "name": "Phục linh",
        "dose": "16g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      },
      {
        "name": "Ngũ vị tử",
        "dose": "8g"
      },
      {
        "name": "Can khương",
        "dose": "12g"
      },
      {
        "name": "Tế tân",
        "dose": "8g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 3 lần",
    "analysis": "Can khương (Quân) ôn phế hàn; Phục linh, Ngũ vị tử, Tế tân (Thần) ôn hóa hàn đàm",
    "contra": "",
    "note": ""
  },
  {
    "id": "linh_que_truat_cam_thang",
    "name": "Linh quế truật cam thang",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Ôn hóa hàn đàm",
    "symptoms": [
      "Ngực sườn đầy tức",
      "ho",
      "khó thở",
      "đầu váng",
      "tim đập nhanh"
    ],
    "effects": [
      "kiện tỳ lợi thấp",
      "ôn hoá đàm ẩm"
    ],
    "indication": "kiện tỳ lợi thấp, ôn hoá đàm ẩm. Bài thuốc trị chứng đàm ẩm gây ngực sườn đầy tức, hoa mắt",
    "herbs": [
      {
        "name": "Phục linh",
        "dose": "16g"
      },
      {
        "name": "Quế chi",
        "dose": "8g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      }
    ],
    "usage": "Mỗi ngày uống 1 thang, sắc uống chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "nhi_tran_thang",
    "name": "Nhị trần thang",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Táo thấp hóa đàm",
    "symptoms": [
      "Ho khạc đờm nhiều",
      "đờm trắng dễ khạc",
      "đầy tức ngực",
      "buồn nôn"
    ],
    "effects": [
      "táo thấp hoá đàm",
      "lý khí hoà trung"
    ],
    "indication": "táo thấp hoá đàm, lý khí hoà trung. Bài thuốc trị chứng ho khạc đờm nhiều, đờm trắng dễ khạc",
    "herbs": [
      {
        "name": "Bán hạ chế",
        "dose": "8-12g"
      },
      {
        "name": "Trần bì",
        "dose": "8-12g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia làm 2 lần",
    "analysis": "Bán hạ (Quân) táo thấp hóa đàm, giáng nghịch; Trần bì (Thần) lý khí hóa đàm để đàm dễ tiêu; Phục linh (Tá) kiện tỳ để triệt nguồn sinh đàm; Cam thảo (Sứ) điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "tang_hanh_thang",
    "name": "Tang hạnh thang",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Nhuận táo hóa đàm",
    "symptoms": [
      "Ho khan không đờm",
      "đầu đau",
      "người nóng",
      "họng khô",
      "miệng khát"
    ],
    "effects": [
      "tuyên phế",
      "thanh ôn táo",
      "chỉ khái"
    ],
    "indication": "tuyên phế, thanh ôn táo, chỉ khái. Bài thuốc trị chứng ho do cảm thụ táo tà thời tiết hanh khô",
    "herbs": [
      {
        "name": "Tang diệp",
        "dose": "12g"
      },
      {
        "name": "Hạnh nhân",
        "dose": "12g"
      },
      {
        "name": "Sa sâm",
        "dose": "12g"
      },
      {
        "name": "Thổ bối mẫu",
        "dose": "12g"
      },
      {
        "name": "Đậu xị",
        "dose": "12g"
      },
      {
        "name": "Chi tử",
        "dose": "6-12g"
      },
      {
        "name": "Lê bì (liều thích hợp)",
        "dose": ""
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_ham_hung_thang",
    "name": "Tiểu hãm hung thang",
    "chapterNumber": 8,
    "chapterTitle": "Bài thuốc trừ đàm",
    "group": "Trừ đàm",
    "subgroup": "Thanh nhiệt hóa đàm",
    "symptoms": [
      "Đau tức vùng thượng vị",
      "ho khạc đờm vàng dính",
      "táo bón"
    ],
    "effects": [
      "thanh nhiệt hóa đàm",
      "khoan hung khai kết"
    ],
    "indication": "thanh nhiệt hóa đàm, khoan hung khai kết. Bài thuốc trị chứng đàm nhiệt kết ở thượng vị gây đau tức ngực",
    "herbs": [
      {
        "name": "Hoàng liên",
        "dose": "8g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "12g"
      },
      {
        "name": "Qua lâu thực",
        "dose": "20g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 3 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bao_hoa_hoan",
    "name": "Bảo hòa hoàn",
    "chapterNumber": 9,
    "chapterTitle": "Bài thuốc tiêu đạo",
    "group": "Tiêu đạo",
    "subgroup": "Tiêu thực đạo trệ",
    "symptoms": [
      "Bụng đầy trướng",
      "ăn không tiêu",
      "ợ hơi ra mùi thức ăn",
      "đại tiện rối loạn",
      "sợ mùi thức ăn"
    ],
    "effects": [
      "tiêu thực",
      "hòa vị"
    ],
    "indication": "tiêu thực, hòa vị. Bài thuốc điều trị chứng thực tích gây bụng đầy tức, ợ chua, sợ ăn",
    "herbs": [
      {
        "name": "Sơn tra",
        "dose": "180g"
      },
      {
        "name": "Thần khúc",
        "dose": "60g"
      },
      {
        "name": "Liên kiều",
        "dose": "30g"
      },
      {
        "name": "Lai phục tử",
        "dose": "30g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "90g"
      },
      {
        "name": "Phục linh",
        "dose": "90g"
      },
      {
        "name": "Trần bì",
        "dose": "30g"
      }
    ],
    "usage": "Tán bột làm hoàn, uống 5-10g/lần ngày 2 lần. Dạng sắc ngày 1 thang chia 2 lần",
    "analysis": "Sơn tra (Quân) tiêu thịt; Thần khúc, Lai phục tử (Thần) tiêu ngũ cốc và khí trệ; Bán hạ, Trần bì, Phục linh hóa thấp; Liên kiều thanh nhiệt",
    "contra": "",
    "note": ""
  },
  {
    "id": "chi_thuc_tieu_bi_hoan",
    "name": "Chỉ thực tiêu bĩ hoàn",
    "chapterNumber": 9,
    "chapterTitle": "Bài thuốc tiêu đạo",
    "group": "Tiêu đạo",
    "subgroup": "Tiêu bĩ hóa tích",
    "symptoms": [
      "Vùng thượng vị đầy trướng",
      "ăn uống kém",
      "mệt mỏi",
      "đại tiện khó khăn"
    ],
    "effects": [
      "tiêu bĩ mãn",
      "kiện tỳ vị"
    ],
    "indication": "tiêu bĩ mãn, kiện tỳ vị. Bài thuốc trị chứng vùng thượng vị đầy trướng, ăn uống kém, mệt mỏi",
    "herbs": [
      {
        "name": "Can khương",
        "dose": "4g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "8g"
      },
      {
        "name": "Mạch nha",
        "dose": "8g"
      },
      {
        "name": "Chích chỉ thực",
        "dose": "20g"
      },
      {
        "name": "Phục linh",
        "dose": "8g"
      },
      {
        "name": "Bạch truật",
        "dose": "8g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "12g"
      },
      {
        "name": "Đảng sâm",
        "dose": "12g"
      },
      {
        "name": "Hậu phác",
        "dose": "16g"
      },
      {
        "name": "Hoàng liên (sao với nước gừng)",
        "dose": "20g"
      }
    ],
    "usage": "Tán bột làm viên hoàn, uống 12-16g/ngày với nước ấm, xa bữa ăn",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "chi_truat_hoan",
    "name": "Chỉ truật hoàn",
    "chapterNumber": 9,
    "chapterTitle": "Bài thuốc tiêu đạo",
    "group": "Tiêu đạo",
    "subgroup": "Tiêu thực đạo trệ",
    "symptoms": [
      "Vùng thượng vị đầy trướng",
      "ăn không tiêu",
      "đại tiện nhão nát hoặc không thông"
    ],
    "effects": [
      "kiện tỳ",
      "tiêu bĩ"
    ],
    "indication": "chứng tỳ hư khí trệ làm thức ăn đình trệ không tiêu",
    "herbs": [
      {
        "name": "Chỉ thực (sao giòn)",
        "dose": "40g"
      },
      {
        "name": "Bạch truật",
        "dose": "80g"
      }
    ],
    "usage": "Dạng hoàn uống 8-12g/lần, ngày 2 lần. Dạng sắc ngày 1 thang chia 2 lần",
    "analysis": "Bạch truật (Quân) kiện tỳ; Chỉ thực (Thần) tiêu bĩ",
    "contra": "",
    "note": ""
  },
  {
    "id": "chu_sa_an_than_hoan_an_than_hoan",
    "name": "Chu sa an thần hoàn (An thần hoàn)",
    "chapterNumber": 10,
    "chapterTitle": "Bài thuốc an thần",
    "group": "An thần",
    "subgroup": "Trọng trấn an thần",
    "symptoms": [],
    "effects": [],
    "indication": "",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoang_lien_a_giao_thang",
    "name": "Hoàng liên a giao thang",
    "chapterNumber": 10,
    "chapterTitle": "Bài thuốc an thần",
    "group": "An thần",
    "subgroup": "Trọng trấn an thần",
    "symptoms": [
      "Mất ngủ",
      "tâm phiền",
      "bứt rứt",
      "chất lưỡi đỏ",
      "rêu khô"
    ],
    "effects": [
      "tư âm giáng hỏa"
    ],
    "indication": "tư âm giáng hỏa. Bài thuốc trị chứng âm hư hoả vượng gây mất ngủ, tâm phiền",
    "herbs": [
      {
        "name": "Hoàng liên",
        "dose": "16g"
      },
      {
        "name": "A giao",
        "dose": "12g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "8g"
      },
      {
        "name": "Kê tử hoàng",
        "dose": "2 quả"
      },
      {
        "name": "Bạch thược",
        "dose": "8g"
      }
    ],
    "usage": "Sắc thuốc xong, hòa tan A giao vào nước sôi, sau đó đập lòng đỏ trứng vào hòa tan rồi sắc lại lần 2",
    "analysis": "Hoàng liên (Quân) tả hỏa; A giao, Bạch thược, Kê tử hoàng (Thần) tư âm dưỡng huyết",
    "contra": "",
    "note": ""
  },
  {
    "id": "thien_vuong_bo_tam_an",
    "name": "Thiên vương bổ tâm đan",
    "chapterNumber": 10,
    "chapterTitle": "Bài thuốc an thần",
    "group": "An thần",
    "subgroup": "Dưỡng tâm an thần",
    "symptoms": [
      "Mất ngủ",
      "hồi hộp",
      "hay quên",
      "mồ hôi trộm",
      "mộng tinh",
      "mệt mỏi"
    ],
    "effects": [
      "tư âm",
      "dưỡng huyết",
      "bổ tâm",
      "an thần"
    ],
    "indication": "tư âm, dưỡng huyết, bổ tâm, an thần. Bài thuốc trị chứng tâm thận âm hư gây mất ngủ, mộng tinh, hay quên",
    "herbs": [
      {
        "name": "Nhân sâm (Đảng sâm)",
        "dose": "16g"
      },
      {
        "name": "Bá tử nhân",
        "dose": "30g"
      },
      {
        "name": "Huyền sâm",
        "dose": "16g"
      },
      {
        "name": "Thiên môn",
        "dose": "30g"
      },
      {
        "name": "Đan sâm",
        "dose": "16g"
      },
      {
        "name": "Mạch môn",
        "dose": "30g"
      },
      {
        "name": "Phục linh",
        "dose": "16g"
      },
      {
        "name": "Sinh địa hoàng",
        "dose": "30g"
      },
      {
        "name": "Ngũ vị tử",
        "dose": "30g"
      },
      {
        "name": "Xuyên quy",
        "dose": "30g"
      },
      {
        "name": "Viễn chí",
        "dose": "16g"
      },
      {
        "name": "Cát cánh",
        "dose": "16g"
      },
      {
        "name": "Hắc táo nhân",
        "dose": "30g"
      }
    ],
    "usage": "Làm viên hoàn (có áo bột Chu sa), uống 10g/ngày chia 2 lần trước khi ngủ",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "toan_tao_nhan_thang",
    "name": "Toan táo nhân thang",
    "chapterNumber": 10,
    "chapterTitle": "Bài thuốc an thần",
    "group": "An thần",
    "subgroup": "Dưỡng tâm an thần",
    "symptoms": [
      "Mất ngủ",
      "nằm mê nhiều",
      "dễ tỉnh",
      "đầu váng",
      "mắt hoa",
      "họng khô"
    ],
    "effects": [
      "trừ hư phiền",
      "an tâm thần"
    ],
    "indication": "chứng hư phiền mất ngủ, chóng mặt, họng khô",
    "herbs": [
      {
        "name": "Toan táo nhân",
        "dose": "8-16g"
      },
      {
        "name": "Tri mẫu",
        "dose": "12g"
      },
      {
        "name": "Xuyên khung",
        "dose": "6g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống mỗi ngày 1 thang, uống trước khi ngủ",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "an_cung_nguu_hoang_hoan",
    "name": "An cung ngưu hoàng hoàn",
    "chapterNumber": 11,
    "chapterTitle": "Bài thuốc khai khiếu",
    "group": "Khai khiếu",
    "subgroup": "Lương khai",
    "symptoms": [
      "Hôn mê",
      "sốt cao co giật",
      "trúng phong hôn mê",
      "đờm dãi ủng tắc"
    ],
    "effects": [
      "thanh nhiệt",
      "khai khiếu",
      "tống đờm",
      "giải độc"
    ],
    "indication": "thanh nhiệt, khai khiếu, tống đờm, giải độc. Bài thuốc trị chứng nhiệt nhập tâm bào gây hôn mê, sốt cao co giật",
    "herbs": [
      {
        "name": "Ngưu hoàng",
        "dose": "40g"
      },
      {
        "name": "Băng phiến",
        "dose": "8g"
      },
      {
        "name": "Uất kim",
        "dose": "40g"
      },
      {
        "name": "Trân châu",
        "dose": "10g"
      },
      {
        "name": "Tê giác",
        "dose": "40g"
      },
      {
        "name": "Chi tử",
        "dose": "40g"
      },
      {
        "name": "Hoàng liên",
        "dose": "40g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "40g"
      },
      {
        "name": "Chu sa",
        "dose": "40g"
      },
      {
        "name": "Xạ hương",
        "dose": "8g"
      },
      {
        "name": "Hùng hoàng",
        "dose": "40g"
      }
    ],
    "usage": "Làm viên hoàn 4g, ngày uống 1 - 2 viên, trẻ em giảm liều",
    "analysis": "Ngưu hoàng, Xạ hương (Quân) thanh tâm khai khiếu; Tê giác (Thần) lương huyết giải độc",
    "contra": "",
    "note": ""
  },
  {
    "id": "chi_bao_an",
    "name": "Chí bảo đan",
    "chapterNumber": 11,
    "chapterTitle": "Bài thuốc khai khiếu",
    "group": "Khai khiếu",
    "subgroup": "Lương khai",
    "symptoms": [
      "Hôn mê nói sảng do sốt cao",
      "đờm thịnh phiền táo",
      "trẻ em sốt cao co giật"
    ],
    "effects": [
      "khai khiếu trấn kinh"
    ],
    "indication": "hôn mê nói sảng do sốt cao, đờm thịnh",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "80g"
      },
      {
        "name": "Băng phiến",
        "dose": "40g"
      },
      {
        "name": "Chu sa",
        "dose": "80g"
      },
      {
        "name": "Ngưu hoàng",
        "dose": "20g"
      },
      {
        "name": "Xạ hương",
        "dose": "4g"
      },
      {
        "name": "Hổ phách",
        "dose": "4g"
      },
      {
        "name": "An tức hương",
        "dose": "20g"
      },
      {
        "name": "Hùng hoàng",
        "dose": "40g"
      },
      {
        "name": "Long não",
        "dose": "40g"
      },
      {
        "name": "Đại mạo",
        "dose": "40g"
      },
      {
        "name": "Tê giác",
        "dose": "40g"
      }
    ],
    "usage": "Uống ngày 1-2 viên với nước sôi để nguội",
    "analysis": "Xạ hương, Băng phiến, An tức hương, Long não (Quân) phương hương khai khiếu",
    "contra": "",
    "note": ""
  },
  {
    "id": "nguu_hoang_thanh_tam_hoan_phu_phuong",
    "name": "Ngưu hoàng thanh tâm hoàn (phụ phương)",
    "chapterNumber": 11,
    "chapterTitle": "Bài thuốc khai khiếu",
    "group": "Khai khiếu",
    "subgroup": "Lương khai",
    "symptoms": [],
    "effects": [],
    "indication": "",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thong_quan_tan",
    "name": "Thông quan tán",
    "chapterNumber": 11,
    "chapterTitle": "Bài thuốc khai khiếu",
    "group": "Khai khiếu",
    "subgroup": "Ôn khai",
    "symptoms": [
      "Bất tỉnh nhân sự đột ngột",
      "môi miệng mím chặt",
      "đờm dãi tắc trở"
    ],
    "effects": [
      "thông quan",
      "khai khiếu"
    ],
    "indication": "thông quan, khai khiếu. Bài thuốc dùng cấp cứu chứng đột ngột bất tỉnh, miệng mím chặt",
    "herbs": [
      {
        "name": "Tạo giác",
        "dose": ""
      },
      {
        "name": "Tế tân (lượng bằng nhau)",
        "dose": ""
      }
    ],
    "usage": "Thổi một lượng ít bột thuốc vào mũi",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "to_hop_huong_hoan",
    "name": "Tô hợp hương hoàn",
    "chapterNumber": 11,
    "chapterTitle": "Bài thuốc khai khiếu",
    "group": "Khai khiếu",
    "subgroup": "Ôn khai",
    "symptoms": [
      "Hôn mê",
      "khít hàm",
      "đau tim bụng đột ngột",
      "chân tay lạnh"
    ],
    "effects": [
      "phương hương khai khiếu",
      "hành khí",
      "chỉ thống"
    ],
    "indication": "phương hương khai khiếu, hành khí, chỉ thống. Bài thuốc trị chứng trúng phong, trúng hàn gây hôn mê, khít hàm",
    "herbs": [
      {
        "name": "Chu sa",
        "dose": ""
      },
      {
        "name": "Đinh hương",
        "dose": ""
      },
      {
        "name": "Mộc hương",
        "dose": "40g"
      },
      {
        "name": "Xạ hương",
        "dose": "28g"
      },
      {
        "name": "Dầu tô hợp hương",
        "dose": "20g"
      },
      {
        "name": "Trầm hương",
        "dose": ""
      },
      {
        "name": "Tê giác",
        "dose": ""
      },
      {
        "name": "An tức hương",
        "dose": ""
      },
      {
        "name": "Hương phụ",
        "dose": ""
      },
      {
        "name": "Bạch truật",
        "dose": ""
      },
      {
        "name": "Bạch đàn hương",
        "dose": ""
      },
      {
        "name": "Tất bát",
        "dose": ""
      },
      {
        "name": "Kha tử",
        "dose": "40g"
      },
      {
        "name": "Long não",
        "dose": "20g"
      },
      {
        "name": "Nhũ hương",
        "dose": "20g"
      }
    ],
    "usage": "Làm viên hoàn 4g, uống 1/2 - 1 viên/lần, ngày 1-2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_tuyet_an",
    "name": "Tử tuyết đan",
    "chapterNumber": 11,
    "chapterTitle": "Bài thuốc khai khiếu",
    "group": "Khai khiếu",
    "subgroup": "Lương khai",
    "symptoms": [
      "Sốt cao",
      "co giật",
      "hôn mê trong bệnh ôn nhiệt"
    ],
    "effects": [
      "khai khiếu",
      "trấn kinh",
      "thanh nhiệt"
    ],
    "indication": "trường hợp sốt cao co giật, hôn mê do nhiệt",
    "herbs": [
      {
        "name": "Hoạt thạch",
        "dose": ""
      },
      {
        "name": "Hàn thuỷ thạch",
        "dose": ""
      },
      {
        "name": "Thạch cao",
        "dose": "1kg"
      },
      {
        "name": "Từ thạch",
        "dose": "2kg"
      },
      {
        "name": "Linh dương giác",
        "dose": "500g"
      },
      {
        "name": "Đinh hương",
        "dose": "500g"
      },
      {
        "name": "Mộc hương",
        "dose": "500g"
      },
      {
        "name": "Thăng ma",
        "dose": "1kg"
      },
      {
        "name": "Tê giác",
        "dose": "500g"
      },
      {
        "name": "Huyền sâm",
        "dose": "1kg"
      },
      {
        "name": "Trầm hương",
        "dose": "500g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "500g"
      },
      {
        "name": "Phác tiêu",
        "dose": "2kg"
      },
      {
        "name": "Tiêu thạch",
        "dose": "2kg"
      },
      {
        "name": "Chu sa",
        "dose": "300g"
      },
      {
        "name": "Xạ hương",
        "dose": "100g"
      }
    ],
    "usage": "Uống mỗi lần 1-4g với nước sôi để nguội, ngày 2-4 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ao_hoa_thang",
    "name": "Đào hoa thang",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Chỉ tả Cố sáp trường vị",
    "symptoms": [
      "Lỵ mãn tính lâu ngày",
      "bụng đau",
      "đi ngoài ra máu mủ"
    ],
    "effects": [
      "ôn trung sáp trường chỉ lỵ"
    ],
    "indication": "lỵ mạn tính, đi ngoài ra máu mủ",
    "herbs": [
      {
        "name": "Xích thạch chỉ",
        "dose": "30g"
      },
      {
        "name": "Can khương",
        "dose": "8g"
      },
      {
        "name": "Ngạnh mễ",
        "dose": "20g"
      }
    ],
    "usage": "Nấu thuốc chắt lấy nước, hòa bột Xích thạch chi vào uống lúc nóng, ngày 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bai_thuoc_cam_ra_mo_hoi",
    "name": "Bài thuốc cầm ra mồ hôi",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Liễm hãn",
    "symptoms": [],
    "effects": [],
    "indication": "",
    "herbs": [
      {
        "name": "Lá dâu bánh tẻ",
        "dose": "200g"
      },
      {
        "name": "Long cốt",
        "dose": "200g"
      },
      {
        "name": "Mẫu lệ",
        "dose": "100g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bo_am_duong_tam_co_tinh_hoan",
    "name": "Bổ âm dưỡng tâm cố tinh hoàn",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Cố tinh sáp niệu",
    "symptoms": [
      "Di tinh",
      "mộng tinh do thận hư"
    ],
    "effects": [
      "bổ thận cố tinh"
    ],
    "indication": "bổ thận cố tinh. Bài thuốc trị di tinh, mộng tinh do cả âm và dương của thận đều hư",
    "herbs": [
      {
        "name": "Thục địa",
        "dose": "160g"
      },
      {
        "name": "Cao quy bản",
        "dose": "100g"
      },
      {
        "name": "Kỷ tử",
        "dose": "120g"
      },
      {
        "name": "Nhục quế",
        "dose": "16g"
      },
      {
        "name": "Cao lộc giác",
        "dose": "100g"
      },
      {
        "name": "Củ mài",
        "dose": "120g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "16g"
      },
      {
        "name": "Khiếm thực",
        "dose": "120g"
      },
      {
        "name": "Thỏ ty tử",
        "dose": "80g"
      }
    ],
    "usage": "Làm hoàn 2g, ngày uống 2 lần, mỗi lần 10g",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bo_thuy_thanh_tam_co_tinh_thang",
    "name": "Bổ thủy thanh tâm cố tinh thang",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Cố tinh sáp niệu",
    "symptoms": [
      "Mộng tinh",
      "hồi hộp do âm hư hỏa vượng"
    ],
    "effects": [
      "bổ thuỷ thanh tâm cố tinh"
    ],
    "indication": "bổ thuỷ thanh tâm cố tinh. Bài thuốc trị mộng tinh do âm hư hoả vượng",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "co_kinh_hoan",
    "name": "Cố kinh hoàn",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Cố băng, chỉ đới",
    "symptoms": [
      "Băng kinh",
      "rong huyết",
      "máu tím đen có huyết cục",
      "tâm phiền",
      "bụng đau"
    ],
    "effects": [
      "tư âm thanh nhiệt",
      "chỉ huyết cố kinh"
    ],
    "indication": "chứng băng kinh, rong huyết do nhiệt",
    "herbs": [
      {
        "name": "Hoàng cầm",
        "dose": "40g"
      },
      {
        "name": "Xuân căn bì",
        "dose": "30g"
      },
      {
        "name": "Hương phụ",
        "dose": "8g"
      },
      {
        "name": "Hoàng bá",
        "dose": "12g"
      },
      {
        "name": "Bạch thược",
        "dose": "40g"
      },
      {
        "name": "Quy bản",
        "dose": "40g"
      }
    ],
    "usage": "Sắc uống hoặc tán bột uống 12g/lần, ngày 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "cuu_tien_tan",
    "name": "Cửu tiên tán",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Liễm phế",
    "symptoms": [
      "Ho lâu ngày do phế khí hư",
      "đoản khí",
      "tự hãn"
    ],
    "effects": [
      "bổ khí dưỡng âm",
      "liễm phế chỉ khái"
    ],
    "indication": "bổ khí dưỡng âm, liễm phế chỉ khái. Bài thuốc trị chứng ho lâu ngày do phế khí hư",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Khoản đông hoa",
        "dose": "12g"
      },
      {
        "name": "Tang bạch bì",
        "dose": "8g"
      },
      {
        "name": "Cát cánh",
        "dose": "4g"
      },
      {
        "name": "Xuyên bối mẫu",
        "dose": "12g"
      },
      {
        "name": "Ngũ vị tử",
        "dose": "8g"
      },
      {
        "name": "Anh túc xác",
        "dose": "8g"
      },
      {
        "name": "A giao",
        "dose": "12g"
      },
      {
        "name": "Ô mai",
        "dose": "4g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, uống nóng chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "duong_tang_thang",
    "name": "Dưỡng tạng thang",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Chỉ tả Cố sáp trường vị",
    "symptoms": [
      "Đi lỏng lâu ngày không cầm được",
      "đau bụng âm ỉ",
      "sa trực tràng"
    ],
    "effects": [
      "ôn bổ tỳ thận sáp trường cố thoát"
    ],
    "indication": "ôn bổ tỳ thận sáp trường cố thoát. Bài thuốc trị chứng tả lỵ kéo dài, sa trực tràng",
    "herbs": [
      {
        "name": "Bạch thược",
        "dose": "60g"
      },
      {
        "name": "Anh túc xác",
        "dose": "100g"
      },
      {
        "name": "Đương quy",
        "dose": "40g"
      },
      {
        "name": "Nhục quế",
        "dose": "32g"
      },
      {
        "name": "Nhân sâm",
        "dose": "20g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "32g"
      },
      {
        "name": "Bạch truật",
        "dose": "20g"
      },
      {
        "name": "Mộc hương",
        "dose": "60g"
      },
      {
        "name": "Nhục đậu khấu",
        "dose": "20g"
      },
      {
        "name": "Kha tử bì",
        "dose": "60g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang chia 2 lần",
    "analysis": "Anh túc xác, Kha tử (Quân) sáp trường; Nhân sâm, Bạch truật, Đương quy, Bạch thược (Thần) bổ khí huyết",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoan_oi_thang",
    "name": "Hoàn đới thang",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Cố băng, chỉ đới",
    "symptoms": [
      "Khí hư ra nhiều màu trắng trong hoặc vàng nhạt",
      "người mệt mỏi",
      "đi lỏng"
    ],
    "effects": [
      "bổ khí kiện tỳ",
      "hoá thấp",
      "chỉ đới"
    ],
    "indication": "bổ khí kiện tỳ, hoá thấp, chỉ đới. Bài thuốc trị chứng khí hư (huyết trắng) ra nhiều",
    "herbs": [
      {
        "name": "Bạch truật",
        "dose": "40g"
      },
      {
        "name": "Sơn dược",
        "dose": "40g"
      },
      {
        "name": "Bạch thược",
        "dose": "20g"
      },
      {
        "name": "Xa tiền tử",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Trần bì",
        "dose": "2g"
      },
      {
        "name": "Sài hồ",
        "dose": "3g"
      },
      {
        "name": "Nhân sâm",
        "dose": "8g"
      },
      {
        "name": "Thương truật",
        "dose": "12g"
      },
      {
        "name": "Kinh giới tuệ",
        "dose": "2g"
      }
    ],
    "usage": "Sắc uống",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "kim_toa_co_tinh_hoan",
    "name": "Kim tỏa cố tinh hoàn",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Cố tinh sáp niệu",
    "symptoms": [
      "Di tinh",
      "hoạt tinh",
      "đau thắt lưng",
      "tai ù",
      "mệt mỏi"
    ],
    "effects": [
      "cố thận liễm tinh"
    ],
    "indication": "cố thận liễm tinh. Bài thuốc trị chứng thận hư di tinh, hoạt tinh, đau lưng",
    "herbs": [],
    "usage": "",
    "analysis": "Sa uyển tật lê (Quân) bổ thận cố tinh; Khiếm thực, Liên tu, Liên nhục (Thần) trợ giúp cố tinh; Long cốt, Mẫu lệ (Tá) trấn tĩnh cố sáp",
    "contra": "",
    "note": ""
  },
  {
    "id": "mau_le_tan",
    "name": "Mẫu lệ tán",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Liễm hãn",
    "symptoms": [
      "Tự hãn (mồ hôi ra ban ngày)",
      "đạo hãn (mồ hôi trộm)",
      "tim đập hồi hộp"
    ],
    "effects": [
      "bổ khí liễm hãn",
      "cố biểu chỉ hãn"
    ],
    "indication": "chứng tự hãn, đạo hãn do cơ thể suy nhược",
    "herbs": [
      {
        "name": "Mẫu lệ (nướng)",
        "dose": "40g"
      },
      {
        "name": "Hoàng kỳ",
        "dose": "16g"
      },
      {
        "name": "Ma hoàng căn",
        "dose": "20g"
      },
      {
        "name": "Phù tiểu mạch",
        "dose": "40g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang chia 2 lần; hoặc tán bột uống 12g/ngày",
    "analysis": "Mẫu lệ (Quân) cố sáp chỉ hãn, trấn tĩnh; Hoàng kỳ (Thần) ích khí cố biểu; Ma hoàng căn, Phù tiểu mạch (Tá, Sứ) hỗ trợ liễm hãn",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngoc_binh_phong_tan",
    "name": "Ngọc bình phong tán",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Liễm hãn",
    "symptoms": [
      "Khí hư tự hãn",
      "cơ thể suy nhược dễ bị cảm mạo"
    ],
    "effects": [
      "bổ khí cố biểu chỉ hãn"
    ],
    "indication": "bổ khí cố biểu chỉ hãn. Bài thuốc trị chứng khí hư tự hãn, dễ bị cảm mạo",
    "herbs": [
      {
        "name": "Phòng phong",
        "dose": "40g"
      },
      {
        "name": "Hoàng kỳ",
        "dose": "40g"
      },
      {
        "name": "Bạch truật",
        "dose": "80g"
      }
    ],
    "usage": "Sắc uống hoặc tán bột uống 12g/lần, chia 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tang_phieu_tieu_tan",
    "name": "Tang phiêu tiêu tán",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Cố tinh sáp niệu",
    "symptoms": [
      "Đi tiểu rắt",
      "tiểu không tự chủ",
      "di niệu",
      "di tinh",
      "hay quên",
      "khó ngủ"
    ],
    "effects": [
      "cố tinh sáp niệu",
      "điều bổ tâm thận"
    ],
    "indication": "cố tinh sáp niệu, điều bổ tâm thận. Bài thuốc trị di tinh, di niệu (đái dầm), tiểu rắt",
    "herbs": [
      {
        "name": "Tang phiêu tiêu",
        "dose": "12g"
      },
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Viễn chí",
        "dose": "8g"
      },
      {
        "name": "Phục thần",
        "dose": "12g"
      },
      {
        "name": "Xương bồ",
        "dose": "6g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Long cốt",
        "dose": "16g"
      },
      {
        "name": "Quy bản",
        "dose": "20g"
      }
    ],
    "usage": "Tán bột uống 10-12g/ngày hoặc sắc uống",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thuoc_ieu_tri_ai_dam",
    "name": "Thuốc điều trị đái dầm",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Cố tinh sáp niệu",
    "symptoms": [
      "Trẻ em đái dầm",
      "người gầy",
      "ăn ít",
      "phân nát"
    ],
    "effects": [
      "bổ khí cố niệu"
    ],
    "indication": "chứng đái dầm ở trẻ em",
    "herbs": [],
    "usage": "Làm hoàn bằng hạt ngô, ngày uống 2 lần, mỗi lần 8-12g",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_than_hoan",
    "name": "Tứ thần hoàn",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Chỉ tả Cố sáp trường vị",
    "symptoms": [
      "Đi lỏng lúc sáng sớm (ngũ canh tả)",
      "ăn kém",
      "đau bụng",
      "chân tay lạnh"
    ],
    "effects": [
      "ôn bổ tỳ thận chỉ tả"
    ],
    "indication": "ôn bổ tỳ thận chỉ tả. Bài thuốc trị chứng ỉa chảy lâu ngày, ngũ canh tả do tỳ thận dương hư",
    "herbs": [
      {
        "name": "Bổ cốt chỉ",
        "dose": "160g"
      },
      {
        "name": "Ngô thù du",
        "dose": "40g"
      },
      {
        "name": "Ngũ vị tử",
        "dose": "80g"
      },
      {
        "name": "Đại táo",
        "dose": "240g"
      },
      {
        "name": "Nhục đậu khấu",
        "dose": "80g"
      }
    ],
    "usage": "Làm hoàn uống ngày 2-3 lần, mỗi lần 1 liều với nước ấm",
    "analysis": "Phá cố chỉ (Quân) ôn thận dương; Ngô thù du (Thần) ôn trung; Nhục đậu khấu, Ngũ vị tử (Tá) sáp trường",
    "contra": "",
    "note": ""
  },
  {
    "id": "vien_to_moc",
    "name": "Viên tô mộc",
    "chapterNumber": 12,
    "chapterTitle": "Bài thuốc cố sáp",
    "group": "Cố sáp",
    "subgroup": "Chỉ tả Cố sáp trường vị",
    "symptoms": [],
    "effects": [],
    "indication": "Bài thuốc dùng điều trị ỉa chảy, kiết lỵ trực trùng",
    "herbs": [
      {
        "name": "Bột cao tô mộc",
        "dose": "100g"
      },
      {
        "name": "Bột gạo nếp rang",
        "dose": "5g"
      },
      {
        "name": "Bột cao lá ổi",
        "dose": "100g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ai_hoang_phu_tu_thang",
    "name": "Đại hoàng phụ tử thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Ôn hạ",
    "symptoms": [
      "Bụng đầy trướng đau",
      "đại tiện bí",
      "chân tay lạnh",
      "sợ lạnh"
    ],
    "effects": [
      "ôn dương",
      "tán hàn",
      "tả kết"
    ],
    "indication": "ôn dương, tán hàn, tả kết. Bài thuốc trị chứng táo bón do hàn tích gây đau bụng, chân tay lạnh",
    "herbs": [
      {
        "name": "Đại hoàng",
        "dose": "12g"
      },
      {
        "name": "Tế tân",
        "dose": "4g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống ngày 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ai_thua_khi_thang",
    "name": "Đại thừa khí thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Hàn hạ",
    "symptoms": [
      "Táo bón",
      "bụng đầy trướng cứng đau",
      "sốt cao mê sảng",
      "nói sảng"
    ],
    "effects": [
      "trừ vị trường thực nhiệt",
      "tiêu bĩ trừ mãn"
    ],
    "indication": "trừ vị trường thực nhiệt, tiêu bĩ trừ mãn. Bài thuốc trị chứng táo bón, bụng đầy chướng đau, sốt cao mê sảng",
    "herbs": [
      {
        "name": "Đại hoàng",
        "dose": "16g"
      },
      {
        "name": "Hậu phác",
        "dose": "16g"
      },
      {
        "name": "Mang tiêu",
        "dose": "20g"
      },
      {
        "name": "Chỉ thực",
        "dose": "16g"
      }
    ],
    "usage": "Sắc uống 1 thang. Đại hoàng và Mang tiêu cho vào sau khi các vị khác đã sắc được; uống lần 1 đã đi ngoài được thì dừng",
    "analysis": "Đại hoàng (Quân) đắng lạnh để tả hỏa, thông đại tiện; Mang tiêu (Thần) nhuận táo làm mềm phân cứng; Hậu phác, Chỉ thực (Tá, Sứ) hành khí tiêu tích giúp tống phân ra ngoài nhanh hơn",
    "contra": "",
    "note": ""
  },
  {
    "id": "bot_truc_thuy",
    "name": "Bột trực thủy",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Trực thủy",
    "symptoms": [],
    "effects": [
      "trục thuỷ"
    ],
    "indication": "trục thuỷ. Bài thuốc trị chứng phù thũng lâu ngày",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "chi_ma_hoan",
    "name": "Chi ma hoàn",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Nhuận hạ",
    "symptoms": [
      "Táo bón do nhiệt",
      "đại tiện khó",
      "miệng khô",
      "hơi thở hôi"
    ],
    "effects": [
      "nhuận tràng",
      "thông tiện"
    ],
    "indication": "táo bón do nhiệt gây khô phân",
    "herbs": [
      {
        "name": "Chi ma",
        "dose": "100g"
      },
      {
        "name": "Tân lang",
        "dose": "40g"
      },
      {
        "name": "Hậu phác",
        "dose": "40g"
      },
      {
        "name": "Ô dược",
        "dose": "30g"
      },
      {
        "name": "Chỉ xác",
        "dose": "30g"
      },
      {
        "name": "Đường",
        "dose": "200g"
      },
      {
        "name": "Muồng trâu",
        "dose": "200g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "gia_vi_tu_vat_phuong",
    "name": "Gia vị tứ vật phương",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Nhuận hạ",
    "symptoms": [
      "Táo bón do âm huyết hư",
      "phân khô khó đi"
    ],
    "effects": [
      "dưỡng huyết thông tiện"
    ],
    "indication": "dưỡng huyết thông tiện. Bài thuốc trị táo bón do âm huyết hư",
    "herbs": [
      {
        "name": "Sinh địa",
        "dose": "20g"
      },
      {
        "name": "Quy thân",
        "dose": "40g"
      },
      {
        "name": "Chỉ xác",
        "dose": "4g"
      },
      {
        "name": "Xuyên khung",
        "dose": "8g"
      },
      {
        "name": "Đại hoàng",
        "dose": "8g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ieu_vi_thua_khi_thang",
    "name": "Điều vị thừa khí thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Hàn hạ",
    "symptoms": [
      "Táo bón",
      "bụng đầy",
      "sốt cao",
      "miệng khát",
      "tâm phiền"
    ],
    "effects": [
      "hoãn hạ nhiệt kết"
    ],
    "indication": "hoãn hạ nhiệt kết. Bài thuốc trị táo bón, sốt cao, miệng khát",
    "herbs": [],
    "usage": "Sắc uống chia 2 lần lúc còn ấm; Mang tiêu cho vào sau cùng",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ky_tieu_lich_hoang_hoan",
    "name": "Kỷ tiêu lịch hoàng hoàn",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Trực thủy",
    "symptoms": [
      "Phù thũng",
      "bụng chướng to",
      "thở gấp",
      "chân tay phù"
    ],
    "effects": [
      "ôn công hạ trục thuỷ ẩm",
      "lợi niệu"
    ],
    "indication": "ôn công hạ trục thuỷ ẩm, lợi niệu. Bài thuốc trị phù thũng, bụng chướng to gây thở gấp",
    "herbs": [
      {
        "name": "Phòng kỷ",
        "dose": ""
      },
      {
        "name": "Đình lịch tử",
        "dose": ""
      },
      {
        "name": "Đại hoàng",
        "dose": "từ 12-20g"
      },
      {
        "name": "Tiêu mục",
        "dose": "4-8g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngu_nhan_hoan",
    "name": "Ngũ nhân hoàn",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Nhuận hạ",
    "symptoms": [
      "Táo bón do tân dịch khô ở người già và phụ nữ sau sinh"
    ],
    "effects": [
      "nhuận tràng thông tiện"
    ],
    "indication": "nhuận tràng thông tiện. Bài thuốc trị táo bón do tân dịch khô ở người già và phụ nữ sau sinh",
    "herbs": [
      {
        "name": "Đào nhân",
        "dose": "12g"
      },
      {
        "name": "Tùng tử nhân",
        "dose": "12g"
      },
      {
        "name": "Hạnh nhân",
        "dose": "12g"
      },
      {
        "name": "Úc lý nhân",
        "dose": "12g"
      },
      {
        "name": "Bá tử nhân",
        "dose": "12g"
      },
      {
        "name": "Trần bì",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "on_ty_thang",
    "name": "Ôn tỳ thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Ôn hạ",
    "symptoms": [
      "Đau bụng",
      "táo bón",
      "chân tay lạnh",
      "lỵ lâu ngày"
    ],
    "effects": [
      "ôn dương",
      "kiện tỳ",
      "công hạ hàn tích"
    ],
    "indication": "ôn dương, kiện tỳ, công hạ hàn tích. Bài thuốc trị chứng tỳ dương hư gây táo bón, lỵ lâu ngày",
    "herbs": [
      {
        "name": "Đại hoàng",
        "dose": "16g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "12g"
      },
      {
        "name": "Can khương",
        "dose": "8g"
      },
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      }
    ],
    "usage": "Sắc uống ngày 2 lần; cần sắc Phụ tử và các vị khác trước, Đại hoàng cho vào sau cùng",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tan_gia_hoang_long_thang",
    "name": "Tân gia hoàng long thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Công bổ kiêm trị",
    "symptoms": [
      "Táo bón",
      "đầy bụng",
      "đi ngoài ra nước không ra bã",
      "mệt mỏi",
      "miệng khô"
    ],
    "effects": [
      "tư âm",
      "ích khí",
      "tả hạ"
    ],
    "indication": "tư âm, ích khí, tả hạ. Bài thuốc trị táo bón kèm khí âm bất túc gây mệt mỏi, miệng khô",
    "herbs": [
      {
        "name": "Đại hoàng",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      },
      {
        "name": "Mang tiêu",
        "dose": "4g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      },
      {
        "name": "Sinh địa",
        "dose": "20g"
      },
      {
        "name": "Nhân sâm",
        "dose": "4g"
      },
      {
        "name": "Mạch đông",
        "dose": "20g"
      },
      {
        "name": "Hải sâm",
        "dose": "2 con"
      },
      {
        "name": "Đương quy",
        "dose": "4g"
      },
      {
        "name": "Huyền sâm",
        "dose": "20g"
      }
    ],
    "usage": "Sắc uống chia nhiều lần; uống đã đi ngoài được thì dừng",
    "analysis": "Đại hoàng, Mang tiêu (Quân) tả hạ; Nhân sâm, Sinh địa, Mạch môn, Đương quy, Huyền sâm (Thần) tư âm ích khí phù chính",
    "contra": "",
    "note": ""
  },
  {
    "id": "tang_dich_thua_khi_thang",
    "name": "Tăng dịch thừa khí thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Công bổ kiêm trị",
    "symptoms": [
      "Sốt cao",
      "táo bón",
      "bụng đầy tức",
      "lưỡi khô",
      "môi nứt"
    ],
    "effects": [
      "tư âm",
      "tăng dịch",
      "thông tiện"
    ],
    "indication": "tư âm, tăng dịch, thông tiện. Bài thuốc dùng khi sốt cao gây táo bón, khô tân dịch",
    "herbs": [
      {
        "name": "Huyền sâm",
        "dose": "40g"
      },
      {
        "name": "Mạch môn",
        "dose": "24g"
      },
      {
        "name": "Đại hoàng",
        "dose": "12g"
      },
      {
        "name": "Mang tiêu",
        "dose": "6g"
      },
      {
        "name": "Sinh địa",
        "dose": "24g"
      }
    ],
    "usage": "Sắc uống, uống 1 bát đã đi được thì dừng",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thap_tao_thang",
    "name": "Thập táo thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Trực thủy",
    "symptoms": [
      "Phù toàn thân",
      "bụng trướng có nước",
      "ho khi nằm",
      "đau tức mạng sườn"
    ],
    "effects": [
      "công trục thuỷ ẩm"
    ],
    "indication": "thuỷ thũng, bụng trướng có nước",
    "herbs": [
      {
        "name": "Cam toại",
        "dose": ""
      },
      {
        "name": "Nguyên hoa",
        "dose": ""
      },
      {
        "name": "Đại kích (liều lượng bằng nhau)",
        "dose": ""
      },
      {
        "name": "Đại táo",
        "dose": "10 quả"
      }
    ],
    "usage": "Tán bột mịn, ngày uống 2-4g lúc đói với nước sắc Đại táo làm thang",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_thua_khi_thang",
    "name": "Tiểu thừa khí thang",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Hàn hạ",
    "symptoms": [
      "Táo bón",
      "bụng đầy tức",
      "triều nhiệt",
      "nói sảng (mức độ nhẹ hơn bài trên)"
    ],
    "effects": [
      "công hạ nhẹ",
      "tiết nhiệt giải độc"
    ],
    "indication": "công hạ nhẹ, tiết nhiệt giải độc. Bài thuốc trị táo bón và bụng đầy nhẹ hơn bài Đại thừa khí",
    "herbs": [],
    "usage": "Sắc uống 1 thang, Đại hoàng cho sau",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "vien_co_truong",
    "name": "Viên cổ trướng",
    "chapterNumber": 13,
    "chapterTitle": "Bài thuốc tả hạ",
    "group": "Tả hạ",
    "subgroup": "Trực thủy",
    "symptoms": [],
    "effects": [
      "tiêu cổ trướng"
    ],
    "indication": "tiêu cổ trướng. Bài thuốc chuyên điều trị bệnh cổ trướng",
    "herbs": [
      {
        "name": "Thanh bì",
        "dose": "16g"
      },
      {
        "name": "Hắc sửu",
        "dose": "40g"
      },
      {
        "name": "Chỉ thực",
        "dose": "16g"
      },
      {
        "name": "Tân lang",
        "dose": "16g"
      },
      {
        "name": "Rễ cỏ tranh",
        "dose": "20g"
      },
      {
        "name": "La bạc tử",
        "dose": "20g"
      },
      {
        "name": "Mộc hương",
        "dose": "20g"
      },
      {
        "name": "Trần bì",
        "dose": "16g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ban_ha_hau_phac_thang",
    "name": "Bán hạ hậu phác thang",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Hành khí",
    "symptoms": [
      "Cảm giác vướng ở họng (nuốt không xuống",
      "khạc không ra)",
      "đầy tức ngực sườn"
    ],
    "effects": [
      "lý khí",
      "giáng nghịch",
      "hoá đàm tán kết"
    ],
    "indication": "lý khí, giáng nghịch, hoá đàm tán kết. Bài thuốc điều trị chứng mai hạch khí (vướng họng)",
    "herbs": [
      {
        "name": "Bán hạ chế",
        "dose": "12g"
      },
      {
        "name": "Hậu phác",
        "dose": "8g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Tử tô",
        "dose": "12g"
      },
      {
        "name": "Sinh khương",
        "dose": "3 lát"
      }
    ],
    "usage": "Sắc uống chia 3 lần dùng trong 2 ngày",
    "analysis": "Bán hạ (Quân) hóa đàm giáng nghịch; Hậu phác (Thần) hành khí tiêu mãn",
    "contra": "",
    "note": ""
  },
  {
    "id": "hau_phac_on_trung_thang",
    "name": "Hậu phác ôn trung thang",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Hành khí",
    "symptoms": [
      "Đầy bụng",
      "ăn kém",
      "khó tiêu",
      "chân tay mệt mỏi"
    ],
    "effects": [
      "ôn trung",
      "hành khí",
      "táo thấp"
    ],
    "indication": "ôn trung, hành khí, táo thấp. Bài thuốc trị chứng tỳ vị hư hàn gây đầy bụng, ăn kém",
    "herbs": [
      {
        "name": "Hậu phác",
        "dose": "40g"
      },
      {
        "name": "Trần bì",
        "dose": "40g"
      },
      {
        "name": "Phục linh",
        "dose": "20g"
      },
      {
        "name": "Nhục đậu khấu",
        "dose": "20g"
      },
      {
        "name": "Can khương",
        "dose": "28g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "20g"
      },
      {
        "name": "Mộc hương",
        "dose": "20g"
      }
    ],
    "usage": "Tán bột, mỗi lần dùng 20g sắc với gừng, uống ấm trước khi ăn",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoa_can_on_than_phuong",
    "name": "Hòa can ôn thận phương",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Hành khí",
    "symptoms": [],
    "effects": [],
    "indication": "",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "inh_huong_thi_e_thang",
    "name": "Đinh hương thị đế thang",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Giáng khí",
    "symptoms": [
      "Nấc cụt",
      "đầy bụng",
      "ợ hơi",
      "không ăn được"
    ],
    "effects": [
      "ôn trung",
      "ích khí giáng nghịch"
    ],
    "indication": "chứng nấc do vị hàn",
    "herbs": [
      {
        "name": "Đinh hương",
        "dose": "6g"
      },
      {
        "name": "Thị đế",
        "dose": "9g"
      },
      {
        "name": "Nhân sâm",
        "dose": "3g"
      },
      {
        "name": "Sinh khương",
        "dose": "6g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "inh_suyen_thang",
    "name": "Định suyễn thang",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Giáng khí",
    "symptoms": [
      "Ho",
      "hen suyễn có nhiệt",
      "đờm nhiều",
      "khó thở cấp"
    ],
    "effects": [
      "tuyên phế giáng khí",
      "bình suyễn",
      "thanh nhiệt"
    ],
    "indication": "tuyên phế giáng khí, bình suyễn, thanh nhiệt. Bài thuốc trị chứng ho hen có nhiệt, đờm nhiều",
    "herbs": [
      {
        "name": "Bạch quả",
        "dose": "12g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "6g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Tô tử",
        "dose": "8g"
      },
      {
        "name": "Tang bạch bì",
        "dose": "12g"
      },
      {
        "name": "Hạnh nhân",
        "dose": "6g"
      },
      {
        "name": "Ma hoàng",
        "dose": "12g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "8g"
      },
      {
        "name": "Khoản đông hoa",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống trong cơn suyễn, uống ngậm từ từ",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thanh_kim_ao_khi_phuong",
    "name": "Thanh kim đạo khí phương",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Giáng khí",
    "symptoms": [],
    "effects": [
      "nhuận phế chỉ nôn"
    ],
    "indication": "nhuận phế chỉ nôn. Bài thuốc chuyên điều trị chứng nôn",
    "herbs": [
      {
        "name": "Mạch môn",
        "dose": "8g"
      },
      {
        "name": "Nhục quế",
        "dose": "4g"
      },
      {
        "name": "Xích linh",
        "dose": "4g"
      },
      {
        "name": "Ngũ vị",
        "dose": "2g"
      },
      {
        "name": "Xa tiền tử",
        "dose": "4g"
      },
      {
        "name": "Ngưu tất",
        "dose": "4g"
      },
      {
        "name": "Trạch tả",
        "dose": "6g"
      },
      {
        "name": "Gừng sống",
        "dose": "3 lát"
      },
      {
        "name": "Trầm hương",
        "dose": "2g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "to_tu_giang_khi_thang",
    "name": "Tô tử giáng khí thang",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Giáng khí",
    "symptoms": [
      "Ho",
      "khó thở cấp",
      "ngực đầy tức",
      "đờm nhiều"
    ],
    "effects": [
      "giáng khí bình suyễn",
      "hóa đờm chỉ khái"
    ],
    "indication": "giáng khí bình suyễn, hóa đờm chỉ khái. Bài thuốc trị hen phế quản, viêm phế quản mạn",
    "herbs": [
      {
        "name": "Tô tử",
        "dose": "100g"
      },
      {
        "name": "Tiền hồ",
        "dose": "40g"
      },
      {
        "name": "Cam thảo",
        "dose": "80g"
      },
      {
        "name": "Đương quy",
        "dose": "80g"
      },
      {
        "name": "Nhục quế",
        "dose": "60g"
      },
      {
        "name": "Hậu phác",
        "dose": "40g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "100g"
      }
    ],
    "usage": "Tán bột mịn (uống 8g/lần) hoặc sắc uống",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "viet_cuc_hoan",
    "name": "Việt cúc hoàn",
    "chapterNumber": 14,
    "chapterTitle": "Bài thuốc lý khí",
    "group": "Lý khí",
    "subgroup": "Hành khí",
    "symptoms": [
      "Ngực sườn đầy tức",
      "ợ chua",
      "buồn nôn",
      "ăn không tiêu",
      "đau bụng"
    ],
    "effects": [
      "hành khí giải uất",
      "hoạt huyết"
    ],
    "indication": "chứng lục uất gây đầy tức ngực sườn, ợ chua, khó tiêu",
    "herbs": [
      {
        "name": "Thương thuật",
        "dose": ""
      },
      {
        "name": "Hương phụ",
        "dose": ""
      },
      {
        "name": "Xuyên khung",
        "dose": ""
      },
      {
        "name": "Thần khúc",
        "dose": ""
      },
      {
        "name": "Chỉ tử (lượng bằng nhau)",
        "dose": ""
      }
    ],
    "usage": "Làm viên hoàn, uống 8-12g/lần, ngày 2 lần hoặc sắc uống",
    "analysis": "Hương phụ (Quân) lý khí giải ngũ uất (huyết, đờm, hỏa, thấp, thực)",
    "contra": "",
    "note": ""
  },
  {
    "id": "ao_nhan_thua_khi_thang",
    "name": "Đào nhân thừa khí thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [
      "Thống kinh",
      "bế kinh",
      "bụng dưới đau cấp",
      "sốt cao",
      "nói sảng"
    ],
    "effects": [
      "phá huyết",
      "trục ứ"
    ],
    "indication": "phá huyết, trục ứ. Bài thuốc trị chứng huyết ứ nội kết gây thống kinh, bế kinh",
    "herbs": [
      {
        "name": "Đào nhân",
        "dose": "12g"
      },
      {
        "name": "Quế chi",
        "dose": "8g"
      },
      {
        "name": "Sinh đại hoàng",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      },
      {
        "name": "Mang tiêu",
        "dose": "8g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang, chia 2-3 lần; nước sắc hòa với bột Mang tiêu đun sôi vài phút",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bai_thuoc_ieu_kinh",
    "name": "Bài thuốc điều kinh",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [],
    "effects": [
      "điều kinh"
    ],
    "indication": "điều kinh. Bài thuốc trị rối loạn kinh nguyệt, thống kinh, thiểu kinh",
    "herbs": [
      {
        "name": "Ích mẫu",
        "dose": "100g"
      },
      {
        "name": "Hương phụ",
        "dose": "50g"
      },
      {
        "name": "Ngải cứu",
        "dose": "50g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bo_duong_hoan_ngu_thang",
    "name": "Bổ dương hoàn ngũ thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [
      "Liệt nửa người",
      "méo mồm",
      "nói ngọng",
      "đại tiện táo sau trúng phong"
    ],
    "effects": [
      "bổ khí",
      "hoạt huyết khử ứ",
      "thông lạc"
    ],
    "indication": "bổ khí, hoạt huyết khử ứ, thông lạc. Bài thuốc trị di chứng trúng phong gây liệt nửa người, méo mồm",
    "herbs": [
      {
        "name": "Sinh hoàng kỳ",
        "dose": "30-60g"
      },
      {
        "name": "Xuyên khung",
        "dose": "4g"
      },
      {
        "name": "Quy vĩ",
        "dose": "8g"
      },
      {
        "name": "Đào nhân",
        "dose": "4g"
      },
      {
        "name": "Xích thược",
        "dose": "4g"
      },
      {
        "name": "Hồng hoa",
        "dose": "4g"
      },
      {
        "name": "Địa long",
        "dose": "4g"
      }
    ],
    "usage": "",
    "analysis": "Sinh hoàng kỳ dùng liều cực cao (Quân) để đại bổ khí, thúc đẩy huyết hành; các vị Quy vĩ, Xích thược, Đào nhân (Thần, Tá) hoạt huyết thông lạc",
    "contra": "",
    "note": ""
  },
  {
    "id": "giao_ngai_thang",
    "name": "Giao ngải thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Chỉ huyết",
    "symptoms": [
      "Băng lậu",
      "rong kinh",
      "động thai ra máu",
      "đau bụng khi mang thai"
    ],
    "effects": [],
    "indication": "",
    "herbs": [
      {
        "name": "Xuyên khung",
        "dose": "6g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "A giao",
        "dose": "12g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "6g"
      },
      {
        "name": "Sinh địa",
        "dose": "40g"
      },
      {
        "name": "Ngải diệp sao",
        "dose": "4g"
      }
    ],
    "usage": "Sắc các vị trước, A giao cho vào hòa tan sau cùng; uống ngày 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoat_huyet_tieu_u_thang",
    "name": "Hoạt huyết tiêu ứ thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [],
    "effects": [
      "hoạt huyết tiêu ứ"
    ],
    "indication": "hoạt huyết tiêu ứ. Bài thuốc trị chứng bế kinh, thống kinh",
    "herbs": [
      {
        "name": "Hương phụ",
        "dose": "40g"
      },
      {
        "name": "Ích mẫu",
        "dose": "20g"
      },
      {
        "name": "Ngải cứu",
        "dose": "16g"
      },
      {
        "name": "Trạch lan",
        "dose": "30g"
      },
      {
        "name": "Nga truật",
        "dose": "20g"
      },
      {
        "name": "Cỏ roi ngựa",
        "dose": "30g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoe_hoa_tan",
    "name": "Hòe hoa tán",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Chỉ huyết",
    "symptoms": [
      "Đi ngoài ra máu tươi trước hoặc sau khi phân ra (bệnh trĩ",
      "lỵ)"
    ],
    "effects": [
      "thanh nhiệt đại trường",
      "chỉ huyết"
    ],
    "indication": "thanh nhiệt đại trường, chỉ huyết. Bài thuốc trị chứng đi ngoài ra máu do nhiệt ở đại tràng",
    "herbs": [
      {
        "name": "Hòe hoa",
        "dose": ""
      },
      {
        "name": "Trắc bách diệp",
        "dose": ""
      },
      {
        "name": "Kinh giới tuệ",
        "dose": ""
      },
      {
        "name": "Chỉ xác (lượng bằng nhau)",
        "dose": ""
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "huyet_phu_truc_u_thang",
    "name": "Huyết phủ trục ứ thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [
      "Đau đầu",
      "đau ngực sườn",
      "hồi hộp",
      "mất ngủ",
      "hay quên"
    ],
    "effects": [
      "hoạt huyết khứ ứ",
      "lý khí chỉ thống"
    ],
    "indication": "hoạt huyết khứ ứ, lý khí chỉ thống. Bài thuốc trị các chứng đau do huyết ứ ở vùng ngực, đầu",
    "herbs": [
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Ngưu tất",
        "dose": "12g"
      },
      {
        "name": "Sinh địa",
        "dose": "12g"
      },
      {
        "name": "Xích thược",
        "dose": "8g"
      },
      {
        "name": "Đào nhân",
        "dose": "16g"
      },
      {
        "name": "Sài hồ",
        "dose": "4g"
      },
      {
        "name": "Hồng hoa",
        "dose": "12g"
      },
      {
        "name": "Cát cánh",
        "dose": "6g"
      },
      {
        "name": "Xuyên khung",
        "dose": "6g"
      },
      {
        "name": "Cam thảo",
        "dose": "4g"
      },
      {
        "name": "Chỉ xác",
        "dose": "8g"
      }
    ],
    "usage": "Sắc uống ngày 1 thang",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "on_kinh_thang",
    "name": "Ôn kinh thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [
      "Rối loạn kinh nguyệt",
      "thống kinh",
      "phụ nữ chậm có con do tử cung lạnh"
    ],
    "effects": [
      "ôn kinh tán hàn",
      "khử ứ",
      "bổ huyết"
    ],
    "indication": "ôn kinh tán hàn, khử ứ, bổ huyết. Bài thuốc trị rối loạn kinh nguyệt, rong kinh do hàn",
    "herbs": [
      {
        "name": "Ngô thù",
        "dose": "8g"
      },
      {
        "name": "Đương quy",
        "dose": "10g"
      },
      {
        "name": "Xuyên khung",
        "dose": "8g"
      },
      {
        "name": "Nhân sâm",
        "dose": "8g"
      },
      {
        "name": "A giao",
        "dose": "8g"
      },
      {
        "name": "Đan bì",
        "dose": "8g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      },
      {
        "name": "Bán hạ chế",
        "dose": "6g"
      },
      {
        "name": "Thược dược",
        "dose": "8g"
      },
      {
        "name": "Sinh khương",
        "dose": "8g"
      },
      {
        "name": "Quế chi",
        "dose": "8g"
      },
      {
        "name": "Mạch môn",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "phuc_nguyen_hoat_huyet_thang",
    "name": "Phục nguyên hoạt huyết thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [
      "Chấn thương gây tụ huyết",
      "sưng đau",
      "đau tức ngực sườn"
    ],
    "effects": [
      "sơ can thông lạc",
      "hoạt huyết khử ứ"
    ],
    "indication": "chấn thương do ngã tụ huyết gây sưng đau",
    "herbs": [
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Đại hoàng",
        "dose": "40g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      },
      {
        "name": "Hồng hoa",
        "dose": "8g"
      },
      {
        "name": "Đào nhân",
        "dose": "16g"
      },
      {
        "name": "Thiên hoa phấn",
        "dose": "12g"
      },
      {
        "name": "Sài hồ",
        "dose": "20g"
      }
    ],
    "usage": "",
    "analysis": "Đào nhân, Hồng hoa, Đương quy (Quân) hoạt huyết khử ứ; Đại hoàng giúp tả hạ huyết ứ; Sài hồ (Thần) sơ can dẫn thuốc đến vùng đau; Thiên hoa phấn nhuận táo",
    "contra": "",
    "note": ""
  },
  {
    "id": "sinh_hoa_thang",
    "name": "Sinh hóa thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Hoạt huyết Hoạt huyết khứ ứ",
    "symptoms": [
      "Phụ nữ sau đẻ bụng dưới đau lạnh",
      "sản dịch ra không ngừng hoặc không ra"
    ],
    "effects": [
      "hoạt huyết tiêu ứ",
      "ôn kinh chỉ thống"
    ],
    "indication": "phụ nữ sau đẻ có sản dịch không ngừng hoặc bụng đau lạnh",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thanh_nhiet_chi_huyet_thang",
    "name": "Thanh nhiệt chỉ huyết thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Chỉ huyết",
    "symptoms": [],
    "effects": [
      "thanh nhiệt lương huyết cầm máu"
    ],
    "indication": "thanh nhiệt lương huyết cầm máu. Bài thuốc trị rong kinh, rong huyết do nhiệt",
    "herbs": [
      {
        "name": "Nền lá sen",
        "dose": "40g"
      },
      {
        "name": "Quả dành dành",
        "dose": "12g"
      },
      {
        "name": "Lá trắc bách",
        "dose": "20g"
      },
      {
        "name": "Lá huyết dụ",
        "dose": "40g"
      },
      {
        "name": "Cỏ nhọ nồi",
        "dose": "40g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thap_khoi_tan",
    "name": "Thập khôi tán",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Chỉ huyết",
    "symptoms": [
      "Nôn ra máu",
      "chảy máu cam",
      "ho ra máu do nhiệt"
    ],
    "effects": [
      "lương huyết chỉ huyết"
    ],
    "indication": "lương huyết chỉ huyết. Bài thuốc trị nhiệt bức huyết vong hành gây nôn ra máu, chảy máu cam",
    "herbs": [
      {
        "name": "Đại kế thảo",
        "dose": ""
      },
      {
        "name": "Tông lư bì",
        "dose": ""
      },
      {
        "name": "Đại hoàng",
        "dose": ""
      },
      {
        "name": "Đan bì",
        "dose": ""
      },
      {
        "name": "Hà diệp",
        "dose": ""
      },
      {
        "name": "Tiểu kế thảo",
        "dose": ""
      },
      {
        "name": "Trắc bách diệp",
        "dose": ""
      },
      {
        "name": "Chi tử",
        "dose": ""
      },
      {
        "name": "Thiên thảo",
        "dose": ""
      },
      {
        "name": "Mao căn (lượng bằng nhau)",
        "dose": ""
      }
    ],
    "usage": "Tán bột mịn, uống 4-12g/lần với nước ấm hoặc nước sắc",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_ke_am_tu",
    "name": "Tiểu kế ẩm tử",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Chỉ huyết",
    "symptoms": [
      "Đi tiểu ra máu",
      "đái buốt",
      "đái rắt"
    ],
    "effects": [
      "lương huyết chỉ huyết",
      "thanh nhiệt"
    ],
    "indication": "lương huyết chỉ huyết, thanh nhiệt. Bài thuốc trị chứng đái ra máu do viêm bàng quang",
    "herbs": [
      {
        "name": "Tiểu kế",
        "dose": "40g"
      },
      {
        "name": "Sinh địa",
        "dose": "40g"
      },
      {
        "name": "Hoạt thạch",
        "dose": "40g"
      },
      {
        "name": "Mộc thông",
        "dose": "4g"
      },
      {
        "name": "Đạm trúc diệp",
        "dose": "12g"
      },
      {
        "name": "Bồ hoàng sao",
        "dose": "12g"
      },
      {
        "name": "Ngẫu tiết",
        "dose": "2g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Chi tử",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống ngày 2 lần",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_u_chi_huyet_thang",
    "name": "Tiêu ứ chỉ huyết thang",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Chỉ huyết",
    "symptoms": [],
    "effects": [
      "tiêu ứ chỉ huyết"
    ],
    "indication": "tiêu ứ chỉ huyết. Bài thuốc trị rong kinh, rong huyết do huyết ứ",
    "herbs": [
      {
        "name": "Cỏ nhọ nồi",
        "dose": "20g"
      },
      {
        "name": "Hương phụ",
        "dose": "20g"
      },
      {
        "name": "Nghệ đen",
        "dose": "20g"
      },
      {
        "name": "Trạch lan",
        "dose": "20g"
      },
      {
        "name": "Ngải diệp",
        "dose": "16g"
      },
      {
        "name": "Tô mộc",
        "dose": "16g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_sinh_hoan",
    "name": "Tứ sinh hoàn",
    "chapterNumber": 15,
    "chapterTitle": "Bài thuốc lý huyết",
    "group": "Lý huyết",
    "subgroup": "Chỉ huyết",
    "symptoms": [
      "Nôn ra máu",
      "chảy máu cam",
      "máu đỏ tươi",
      "họng khô"
    ],
    "effects": [
      "lương huyết chỉ huyết"
    ],
    "indication": "huyết nhiệt gây nôn ra máu, ho ra máu",
    "herbs": [
      {
        "name": "Hà diệp tươi",
        "dose": "1/2 lá"
      },
      {
        "name": "Ngải diệp tươi",
        "dose": "12g"
      },
      {
        "name": "Trắc bách diệp tươi",
        "dose": "40g"
      },
      {
        "name": "Sinh địa tươi",
        "dose": "40g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ai_bo_am_hoan",
    "name": "Đại bổ âm hoàn",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [],
    "effects": [
      "tư âm giáng hỏa"
    ],
    "indication": "tư âm giáng hỏa. Bài thuốc trị chứng can thận âm hư hỏa vượng",
    "herbs": [
      {
        "name": "Hoàng bá",
        "dose": "100g"
      },
      {
        "name": "Tuỷ lợn",
        "dose": "1 bộ"
      },
      {
        "name": "Thục địa",
        "dose": "150g"
      },
      {
        "name": "Tri mẫu",
        "dose": "100g"
      },
      {
        "name": "Quy bản",
        "dose": "150g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bat_tran_thang",
    "name": "Bát trân thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí huyết",
    "symptoms": [
      "Da xanh nhợt",
      "mệt mỏi",
      "đoản hơi",
      "hồi hộp",
      "ăn ít"
    ],
    "effects": [
      "bổ khí huyết"
    ],
    "indication": "bổ khí huyết. Bài thuốc trị chứng khí huyết đều hư gây da xanh nhợt, mệt mỏi",
    "herbs": [
      {
        "name": "Đương quy",
        "dose": "4g"
      },
      {
        "name": "Xuyên khung",
        "dose": "4g"
      },
      {
        "name": "Thục địa",
        "dose": "4g"
      },
      {
        "name": "Bạch thược",
        "dose": "4g"
      },
      {
        "name": "Nhân sâm",
        "dose": "4g"
      },
      {
        "name": "Phục linh",
        "dose": "4g"
      },
      {
        "name": "Bạch truật",
        "dose": "4g"
      },
      {
        "name": "Cam thảo",
        "dose": "2g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bo_duong_tiep_am_phuong",
    "name": "Bổ dương tiếp âm phương",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ dương",
    "symptoms": [],
    "effects": [
      "bổ dương tiếp âm"
    ],
    "indication": "bổ dương tiếp âm. Bài thuốc trị người gầy yếu, sợ lạnh",
    "herbs": [
      {
        "name": "Bố chính sâm",
        "dose": "40g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "60g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "12g"
      },
      {
        "name": "Bạch truật",
        "dose": "60g"
      },
      {
        "name": "Thục địa",
        "dose": "40g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bo_huyet_ieu_kinh_thang",
    "name": "Bổ huyết điều kinh thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ huyết",
    "symptoms": [],
    "effects": [
      "bổ huyết điều kinh"
    ],
    "indication": "vô kinh, bế kinh do huyết hư",
    "herbs": [
      {
        "name": "Lá sung",
        "dose": "40g"
      },
      {
        "name": "Đậu đen",
        "dose": "40g"
      },
      {
        "name": "Ích mẫu",
        "dose": "20g"
      },
      {
        "name": "Ngải cứu",
        "dose": "16g"
      },
      {
        "name": "Hà thủ ô chế",
        "dose": "40g"
      },
      {
        "name": "Củ gấu",
        "dose": "40g"
      },
      {
        "name": "Củ gai",
        "dose": "20g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "bo_trung_ich_khi_thang",
    "name": "Bổ trung ích khí thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí",
    "symptoms": [
      "Mệt mỏi",
      "ăn kém",
      "tự ra mồ hôi",
      "sa tử cung",
      "sa trực tràng",
      "rong kinh"
    ],
    "effects": [
      "bổ trung ích khí",
      "thăng dương cử hãm"
    ],
    "indication": "bổ trung ích khí, thăng dương cử hãm. Bài thuốc trị tỳ vị khí hư, sa tử cung, sa trực tràng",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "6g"
      },
      {
        "name": "Hoàng kỳ",
        "dose": "12g"
      },
      {
        "name": "Trần bì",
        "dose": "4g"
      },
      {
        "name": "Đương quy",
        "dose": "8g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "6g"
      },
      {
        "name": "Bạch truật",
        "dose": "8g"
      },
      {
        "name": "Sài hồ",
        "dose": "6g"
      },
      {
        "name": "Thăng ma",
        "dose": "6g"
      }
    ],
    "usage": "Sắc uống xa bữa ăn, uống ấm; hoặc làm hoàn uống 10-15g/lần",
    "analysis": "Hoàng kỳ (Quân) bổ khí thăng dương; Nhân sâm, Bạch truật, Cam thảo (Thần) kiện tỳ; Thăng ma, Sài hồ (Sứ) thăng đề khí hãm",
    "contra": "",
    "note": ""
  },
  {
    "id": "chich_cam_thao_thang",
    "name": "Chích cam thảo thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí huyết",
    "symptoms": [],
    "effects": [
      "ích khí",
      "tư âm",
      "bổ dưỡng phục mạch"
    ],
    "indication": "ích khí, tư âm, bổ dưỡng phục mạch. Bài thuốc trị chứng mạch kết đại, hồi hộp",
    "herbs": [
      {
        "name": "Chích cam thảo",
        "dose": "12g"
      },
      {
        "name": "A giao",
        "dose": "8g"
      },
      {
        "name": "Nhân sâm",
        "dose": "8g"
      },
      {
        "name": "Sinh địa",
        "dose": "16g"
      },
      {
        "name": "Ma nhân",
        "dose": "8g"
      },
      {
        "name": "Mạch môn",
        "dose": "8g"
      },
      {
        "name": "Quế chi",
        "dose": "8g"
      },
      {
        "name": "Đại táo",
        "dose": "10 quả"
      },
      {
        "name": "Sinh khương",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ha_sa_ai_tao_hoan",
    "name": "Hà sa đại tạo hoàn",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [],
    "effects": [
      "đại bổ âm dương khí huyết"
    ],
    "indication": "người mắc bệnh hư tổn lâu ngày",
    "herbs": [
      {
        "name": "Tử hà sa",
        "dose": "1 cái"
      },
      {
        "name": "Quy bản",
        "dose": "50g"
      },
      {
        "name": "Thục địa",
        "dose": "50g"
      },
      {
        "name": "Mạch môn",
        "dose": "30g"
      },
      {
        "name": "Thiên môn",
        "dose": "30g"
      },
      {
        "name": "Nhân sâm",
        "dose": "25g"
      },
      {
        "name": "Đỗ trọng",
        "dose": "40g"
      },
      {
        "name": "Hoàng bá",
        "dose": "40g"
      },
      {
        "name": "Ngưu tất",
        "dose": "30g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "hau_thien_luc_vi_phuong",
    "name": "Hậu thiên lục vị phương",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ huyết",
    "symptoms": [],
    "effects": [
      "tư âm",
      "bổ huyết"
    ],
    "indication": "tư âm, bổ huyết. Bài thuốc trị chứng thiếu máu, người gầy khô",
    "herbs": [
      {
        "name": "Thục địa",
        "dose": "25g"
      },
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Đan sâm",
        "dose": "8g"
      },
      {
        "name": "Viễn chí",
        "dose": "12g"
      },
      {
        "name": "Đương quy",
        "dose": "20g"
      },
      {
        "name": "Táo nhân",
        "dose": "4g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ho_tiem_hoan",
    "name": "Hổ tiềm hoàn",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [],
    "effects": [
      "tư âm giáng hoả",
      "cường mạnh gân xương"
    ],
    "indication": "tư âm giáng hoả, cường mạnh gân xương. Bài thuốc trị chứng can thận bất túc gây yếu chân tay",
    "herbs": [
      {
        "name": "Hoàng bá",
        "dose": "200g"
      },
      {
        "name": "Quy bản",
        "dose": "100g"
      },
      {
        "name": "Thục địa",
        "dose": "50g"
      },
      {
        "name": "Tri mẫu",
        "dose": "50g"
      },
      {
        "name": "Hổ cốt",
        "dose": "25g"
      },
      {
        "name": "Trần bì",
        "dose": "50g"
      },
      {
        "name": "Can khương",
        "dose": "12g"
      },
      {
        "name": "Thược dược",
        "dose": "50g"
      },
      {
        "name": "Toả dương",
        "dose": "40g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "huu_quy_hoan",
    "name": "Hữu quy hoàn",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ dương",
    "symptoms": [
      "Dương vật không cương",
      "hoạt tinh",
      "chân tay lạnh",
      "người già suy nhược"
    ],
    "effects": [
      "ôn bổ thận dương",
      "trấn thống huyết"
    ],
    "indication": "ôn bổ thận dương, trấn thống huyết. Bài thuốc trị chứng thận dương bất túc, mệnh môn hỏa suy",
    "herbs": [
      {
        "name": "Thục địa",
        "dose": "320g"
      },
      {
        "name": "Đỗ trọng",
        "dose": "160g"
      },
      {
        "name": "Sơn dược",
        "dose": "160g"
      },
      {
        "name": "Kỷ tử",
        "dose": "160g"
      },
      {
        "name": "Sơn thù",
        "dose": "160g"
      },
      {
        "name": "Thỏ ty tử",
        "dose": "160g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "80-240g"
      },
      {
        "name": "Lộc giác giao",
        "dose": "160g"
      },
      {
        "name": "Nhục quế",
        "dose": "120g"
      },
      {
        "name": "Đương quy",
        "dose": "120g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ieu_nguyen_cuu_ban_thang",
    "name": "Điều nguyên cứu bản thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ dương",
    "symptoms": [],
    "effects": [
      "bổ tỳ thận dương"
    ],
    "indication": "bổ tỳ thận dương. Bài thuốc trị chứng ỉa lỏng lâu ngày do tỳ thận dương hư",
    "herbs": [
      {
        "name": "Bạch truật",
        "dose": "40g"
      },
      {
        "name": "Sơn dược",
        "dose": "20g"
      },
      {
        "name": "Thục địa",
        "dose": "8g"
      },
      {
        "name": "Thỏ ty tử",
        "dose": "16g"
      },
      {
        "name": "Phá cố chỉ",
        "dose": "12g"
      },
      {
        "name": "Nhục quế",
        "dose": "3g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "luc_vi_ia_hoang_hoan",
    "name": "Lục vị địa hoàng hoàn",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [
      "Đau lưng",
      "mỏi gối",
      "hoa mắt",
      "tai ù",
      "mồ hôi trộm",
      "di tinh"
    ],
    "effects": [
      "tư bổ can thận"
    ],
    "indication": "chứng can thận âm hư gây đau lưng, mỏi gối, hoa mắt",
    "herbs": [
      {
        "name": "Thục địa",
        "dose": "32g"
      },
      {
        "name": "Trạch tả",
        "dose": "12g"
      },
      {
        "name": "Sơn thù",
        "dose": "16g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Hoài sơn",
        "dose": "16g"
      },
      {
        "name": "Đan bì",
        "dose": "12g"
      }
    ],
    "usage": "Làm hoàn luyện mật, mỗi ngày uống 8-16g chia 2 lần; hoặc sắc uống",
    "analysis": "Thục địa (Quân) bổ thận âm, ích tinh huyết; Sơn thù bổ can, Sơn dược bổ tỳ (Thần); Trạch tả, Đan bì, Phục linh (Tá) là \"tam tả\" giúp sơ thông thận, can, tỳ để hỗ trợ \"tam bổ\" đạt hiệu quả tốt nhất",
    "contra": "",
    "note": ""
  },
  {
    "id": "nhan_sam_cap_gioi_tan",
    "name": "Nhân sâm cáp giới tán",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí",
    "symptoms": [
      "Ho suyễn lâu ngày",
      "đờm vàng dính",
      "người gầy",
      "mặt phù"
    ],
    "effects": [
      "ích khí",
      "thanh phế chỉ khái"
    ],
    "indication": "ích khí, thanh phế chỉ khái. Bài thuốc trị ho suyễn lâu ngày, phế thận lưỡng hư",
    "herbs": [
      {
        "name": "Cáp giới",
        "dose": "1 đôi"
      },
      {
        "name": "Hạnh nhân",
        "dose": "130g"
      },
      {
        "name": "Nhân sâm",
        "dose": "50g"
      },
      {
        "name": "Phục linh",
        "dose": "50g"
      },
      {
        "name": "Cam thảo",
        "dose": "130g"
      },
      {
        "name": "Tang bạch bì",
        "dose": "50g"
      },
      {
        "name": "Tri mẫu",
        "dose": "50g"
      },
      {
        "name": "Bối mẫu",
        "dose": "50g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "oc_long_am",
    "name": "Độc long ẩm",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [],
    "effects": [
      "bổ tinh tuỷ",
      "bổ thận âm",
      "mạnh gân cốt"
    ],
    "indication": "bổ tinh tuỷ, bổ thận âm, mạnh gân cốt. Bài thuốc trị suy nhược cơ thể, đau mỏi gân cốt",
    "herbs": [],
    "usage": "Thái mỏng mỗi miếng 10g, hòa nước ấm hoặc sữa/cháo nóng, ngậm tan nuốt dần; cần uống nóng",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "oc_sam_thang",
    "name": "Độc sâm thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí",
    "symptoms": [
      "Mất máu nhiều",
      "suy tim",
      "mồ hôi lạnh",
      "chân tay lạnh",
      "lơ mơ"
    ],
    "effects": [
      "ích khí cố thoát",
      "đại bổ nguyên khí"
    ],
    "indication": "ích khí cố thoát, đại bổ nguyên khí. Bài thuốc dùng cấp cứu khi xuất huyết nhiều, suy tim, thoát dương",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "quy_ty_thang",
    "name": "Quy tỳ thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ huyết",
    "symptoms": [
      "Ăn ngủ kém",
      "hay quên",
      "hồi hộp",
      "da xanh",
      "kinh nguyệt kéo dài"
    ],
    "effects": [
      "ích khí",
      "kiện tỳ",
      "bổ huyết dưỡng tâm"
    ],
    "indication": "ích khí, kiện tỳ, bổ huyết dưỡng tâm. Bài thuốc trị chứng tâm tỳ lưỡng hư gây ăn ngủ kém, hay quên",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Toan táo nhân",
        "dose": "12g"
      },
      {
        "name": "Hoàng kỳ",
        "dose": "20g"
      },
      {
        "name": "Mộc hương",
        "dose": "2g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "2g"
      },
      {
        "name": "Phục thần",
        "dose": "12g"
      },
      {
        "name": "Viễn chí",
        "dose": "4g"
      },
      {
        "name": "Đương quy",
        "dose": "4g"
      },
      {
        "name": "Long nhãn",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "Nhân sâm, Bạch truật, Hoàng kỳ, Chích cam thảo (Quân) bổ khí kiện tỳ; Đương quy, Long nhãn (Thần) bổ huyết; Táo nhân, Viễn chí, Phục thần (Tá) an thần; Mộc hương (Sứ) lý khí",
    "contra": "",
    "note": ""
  },
  {
    "id": "sam_linh_bach_truat_tan",
    "name": "Sâm linh bạch truật tán",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí",
    "symptoms": [
      "Tiêu chảy mãn tính",
      "ăn ít",
      "phân sống",
      "trẻ em gầy còm"
    ],
    "effects": [
      "bổ khí",
      "kiện tỳ",
      "hóa thấp",
      "chỉ tả"
    ],
    "indication": "bổ khí, kiện tỳ, hóa thấp, chỉ tả. Bài thuốc trị chứng ỉa chảy mạn tính do tỳ hư",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Ý dĩ nhân",
        "dose": "12g"
      },
      {
        "name": "Biển đậu",
        "dose": "12g"
      },
      {
        "name": "Liên nhục",
        "dose": "12g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Cát cánh",
        "dose": "8g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "4g"
      },
      {
        "name": "Sa nhân",
        "dose": "6g"
      },
      {
        "name": "Hoài sơn",
        "dose": "12g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "sinh_mach_tan",
    "name": "Sinh mạch tán",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí",
    "symptoms": [
      "Người mệt",
      "khí đoản (thở ngắn)",
      "họng khô khát",
      "mạch yếu"
    ],
    "effects": [
      "ích khí",
      "dưỡng âm",
      "liễm hãn"
    ],
    "indication": "ích khí, dưỡng âm, liễm hãn. Bài thuốc dùng sau khi mắc ôn bệnh gây mất tân dịch, mệt mỏi",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "4-12g"
      },
      {
        "name": "Mạch đông",
        "dose": "16g"
      },
      {
        "name": "Ngũ vị tử",
        "dose": "4-16g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ta_quy_hoan",
    "name": "Tả quy hoàn",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [],
    "effects": [
      "bổ can thận",
      "ích tinh huyết"
    ],
    "indication": "bổ can thận, ích tinh huyết. Bài thuốc trị chứng chân âm bất túc",
    "herbs": [
      {
        "name": "Thục địa",
        "dose": "200g"
      },
      {
        "name": "Lộc giác giao",
        "dose": "100g"
      },
      {
        "name": "Sơn thù",
        "dose": "100g"
      },
      {
        "name": "Câu kỷ tử",
        "dose": "100g"
      },
      {
        "name": "Sơn dược",
        "dose": "100g"
      },
      {
        "name": "Ngưu tất",
        "dose": "75g"
      },
      {
        "name": "Thỏ ty tử",
        "dose": "100g"
      },
      {
        "name": "Cao quy bản",
        "dose": "100g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thai_son_ban_thach_am",
    "name": "Thái sơn bàn thạch ẩm",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí huyết",
    "symptoms": [],
    "effects": [
      "ích khí",
      "kiện tỳ",
      "dưỡng huyết an thai"
    ],
    "indication": "ích khí, kiện tỳ, dưỡng huyết an thai. Bài thuốc trị chứng động thai, phòng sảy thai liên tục",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Hoàng kỳ",
        "dose": "12g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Hoàng cầm",
        "dose": "12g"
      },
      {
        "name": "Thục địa",
        "dose": "20g"
      },
      {
        "name": "Xuyên khung",
        "dose": "4g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      },
      {
        "name": "Chích cam thảo",
        "dose": "2g"
      },
      {
        "name": "Sa nhân",
        "dose": "2g"
      },
      {
        "name": "Tục đoạn",
        "dose": "12g"
      },
      {
        "name": "Gạo nếp",
        "dose": "1 nắm"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "than_khi_hoan",
    "name": "Thận khí hoàn",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ dương",
    "symptoms": [
      "Lưng gối lạnh đau",
      "tiểu đêm nhiều",
      "phù thũng",
      "đi lỏng sáng sớm"
    ],
    "effects": [
      "bổ thận dương"
    ],
    "indication": "bổ thận dương. Bài thuốc trị chứng thận dương bất túc gây lưng gối lạnh đau, tiểu đêm",
    "herbs": [
      {
        "name": "Thục địa",
        "dose": "320g"
      },
      {
        "name": "Đan bì",
        "dose": "120g"
      },
      {
        "name": "Trạch tả",
        "dose": "120g"
      },
      {
        "name": "Phục linh",
        "dose": "120g"
      },
      {
        "name": "Sơn dược",
        "dose": "160g"
      },
      {
        "name": "Sơn thù",
        "dose": "160g"
      },
      {
        "name": "Quế chi",
        "dose": "40g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "40g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thap_toan_ai_bo",
    "name": "Thập toàn đại bổ",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí huyết",
    "symptoms": [],
    "effects": [
      "bổ khí",
      "bổ dương",
      "bổ huyết"
    ],
    "indication": "bổ khí, bổ dương, bổ huyết. Bài thuốc trị khí huyết và dương đều hư",
    "herbs": [
      {
        "name": "Bát trân gia thêm Hoàng kỳ",
        "dose": "12g"
      },
      {
        "name": "Nhục quế",
        "dose": "4g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_am_giang_hoa_thang",
    "name": "Tư âm giáng hỏa thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [],
    "effects": [
      "tư âm giáng hoả"
    ],
    "indication": "chứng âm hư hỏa vượng trong bệnh cao huyết áp",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_quan_tu_thang",
    "name": "Tứ quân tử thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí",
    "symptoms": [
      "Người gầy",
      "ăn ít",
      "chân tay mỏi yếu",
      "tiêu chảy phân nát"
    ],
    "effects": [
      "kiện tỳ",
      "ích khí hòa trung"
    ],
    "indication": "kiện tỳ, ích khí hòa trung. Bài thuốc trị chứng tỳ vị khí hư gây gầy yếu, ăn ít, đi ngoài lỏng",
    "herbs": [
      {
        "name": "Nhân sâm",
        "dose": "12g"
      },
      {
        "name": "Bạch truật",
        "dose": "12g"
      },
      {
        "name": "Phục linh",
        "dose": "12g"
      },
      {
        "name": "Cam thảo",
        "dose": "8g"
      }
    ],
    "usage": "Tán bột uống 8-12g/lần hoặc sắc uống",
    "analysis": "Nhân sâm (Quân) đại bổ nguyên khí; Bạch truật (Thần) kiện tỳ táo thấp; Phục linh (Tá) thẩm thấp giúp tỳ khô ráo; Cam thảo (Sứ) điều hòa và ích khí",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_tuong_cao",
    "name": "Tứ tượng cao",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ khí huyết",
    "symptoms": [],
    "effects": [
      "bổ khí huyết"
    ],
    "indication": "bổ khí huyết. Bài thuốc điều trị chứng khí huyết đều hư",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tu_vat_thang",
    "name": "Tứ vật thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ huyết",
    "symptoms": [
      "Sắc mặt nhợt",
      "hoa mắt",
      "chóng mặt",
      "kinh nguyệt không đều"
    ],
    "effects": [
      "bổ huyết",
      "hoạt huyết"
    ],
    "indication": "chứng huyết hư gây sắc mặt nhợt, kinh nguyệt không đều",
    "herbs": [
      {
        "name": "Đương quy",
        "dose": "12g"
      },
      {
        "name": "Bạch thược",
        "dose": "12g"
      },
      {
        "name": "Thục địa",
        "dose": "12g"
      },
      {
        "name": "Xuyên khung",
        "dose": "6g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "uong_quy_bo_huyet_thang",
    "name": "Đương quy bổ huyết thang",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ huyết",
    "symptoms": [],
    "effects": [
      "bổ khí",
      "sinh huyết"
    ],
    "indication": "bổ khí, sinh huyết. Bài thuốc trị thiếu máu do mất máu cấp",
    "herbs": [
      {
        "name": "Hoàng kỳ",
        "dose": "40g"
      },
      {
        "name": "Đương quy",
        "dose": "12g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "vien_than_am_hu",
    "name": "Viên thận âm hư",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ âm",
    "symptoms": [],
    "effects": [
      "bổ can thận",
      "ích tinh huyết"
    ],
    "indication": "bổ can thận, ích tinh huyết. Bài thuốc trị chứng thiếu năng sinh dục nam do thận âm hư",
    "herbs": [
      {
        "name": "Thục địa",
        "dose": "200g"
      },
      {
        "name": "Thỏ ty tử",
        "dose": "80g"
      },
      {
        "name": "Sơn dược",
        "dose": "150g"
      },
      {
        "name": "Yếm rùa",
        "dose": "200g"
      },
      {
        "name": "Tỳ giải",
        "dose": "100g"
      },
      {
        "name": "Thạch hộc",
        "dose": "80g"
      },
      {
        "name": "Sừng nai",
        "dose": "150g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "vien_than_duong_hu",
    "name": "Viên thận dương hư",
    "chapterNumber": 16,
    "chapterTitle": "Bài thuốc bổ",
    "group": "Bổ",
    "subgroup": "Bổ dương",
    "symptoms": [],
    "effects": [
      "bổ thận tráng dương"
    ],
    "indication": "chứng liệt dương do thận dương hư",
    "herbs": [
      {
        "name": "Sừng hươu",
        "dose": "200g"
      },
      {
        "name": "Thục địa",
        "dose": "160g"
      },
      {
        "name": "Củ mài",
        "dose": "160g"
      },
      {
        "name": "Tiểu hồi",
        "dose": "60g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "16g"
      },
      {
        "name": "Ba kích",
        "dose": "80g"
      },
      {
        "name": "Quế",
        "dose": "30g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "hoan_tay_giun",
    "name": "Hoàn tẩy giun",
    "chapterNumber": 17,
    "chapterTitle": "Bài thuốc khu trùng",
    "group": "Khu trùng",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Đau bụng quanh rốn",
      "nôn ra nước trong do giun đũa"
    ],
    "effects": [],
    "indication": "Bài thuốc chuyên dùng để tẩy giun đũa",
    "herbs": [
      {
        "name": "Sử quân tử",
        "dose": "120g"
      },
      {
        "name": "Tân lang",
        "dose": "160g"
      },
      {
        "name": "Hắc sửu",
        "dose": "100g"
      },
      {
        "name": "Mộc hương",
        "dose": "80g"
      }
    ],
    "usage": "Làm hoàn mật, uống liền 3 buổi sáng (người lớn 12g, trẻ em giảm liều)",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "o_mai_hoan",
    "name": "Ô mai hoàn",
    "chapterNumber": 17,
    "chapterTitle": "Bài thuốc khu trùng",
    "group": "Khu trùng",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Đau bụng dữ dội từng cơn",
      "chân tay lạnh",
      "nôn ra giun"
    ],
    "effects": [
      "an trùng chỉ thống"
    ],
    "indication": "an trùng chỉ thống. Bài thuốc trị đau bụng do giun, giun chui ống mật",
    "herbs": [
      {
        "name": "Can khương",
        "dose": "300g"
      },
      {
        "name": "Thục tiêu",
        "dose": "120g"
      },
      {
        "name": "Phụ tử chế",
        "dose": "180g"
      },
      {
        "name": "Nhân sâm",
        "dose": "180g"
      },
      {
        "name": "Ô mai",
        "dose": "480g"
      },
      {
        "name": "Tế tân",
        "dose": "180g"
      },
      {
        "name": "Hoàng liên",
        "dose": "480g"
      },
      {
        "name": "Đương quy",
        "dose": "120g"
      },
      {
        "name": "Quế chi",
        "dose": "180g"
      },
      {
        "name": "Hoàng bá",
        "dose": "20g"
      }
    ],
    "usage": "",
    "analysis": "Ô mai (Quân) vị chua làm yên giun; Hoàng liên, Hoàng bá (Thần) thanh nhiệt; Phụ tử, Can khương, Quế chi ôn tạng hàn để đuổi giun; Nhân sâm, Đương quy bổ khí huyết",
    "contra": "",
    "note": ""
  },
  {
    "id": "phi_nhi_cam_tich",
    "name": "Phì nhi cam tích",
    "chapterNumber": 17,
    "chapterTitle": "Bài thuốc khu trùng",
    "group": "Khu trùng",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "ôn bổ tỳ vị khu trùng"
    ],
    "indication": "ôn bổ tỳ vị khu trùng. Bài thuốc trị trẻ em có giun, suy dinh dưỡng",
    "herbs": [
      {
        "name": "Ý dĩ",
        "dose": "40g"
      },
      {
        "name": "Sử quân tử",
        "dose": "30g"
      },
      {
        "name": "Hoài sơn",
        "dose": "40g"
      },
      {
        "name": "Sơn tra",
        "dose": "30g"
      },
      {
        "name": "Hạt sen",
        "dose": "30g"
      },
      {
        "name": "Thần khúc",
        "dose": "16g"
      },
      {
        "name": "Đương quy",
        "dose": "200g"
      },
      {
        "name": "Bạch biển đậu",
        "dose": "40g"
      },
      {
        "name": "Gạo nếp rang",
        "dose": "100g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "phi_nhi_hoan",
    "name": "Phì nhi hoàn",
    "chapterNumber": 17,
    "chapterTitle": "Bài thuốc khu trùng",
    "group": "Khu trùng",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Trẻ em bụng to",
      "gầy yếu",
      "ăn kém",
      "đau bụng giun"
    ],
    "effects": [
      "sát trùng tiêu tích kiện tỳ",
      "thanh nhiệt"
    ],
    "indication": "sát trùng tiêu tích kiện tỳ, thanh nhiệt. Bài thuốc trị đau bụng giun, tiêu hóa kém ở trẻ em",
    "herbs": [
      {
        "name": "Thần khúc",
        "dose": "400g"
      },
      {
        "name": "Hoàng liên",
        "dose": "400g"
      },
      {
        "name": "Nhục đậu khấu",
        "dose": "200g"
      },
      {
        "name": "Sử quân tử",
        "dose": "200g"
      },
      {
        "name": "Tân lang",
        "dose": "160g"
      },
      {
        "name": "Mạch nha",
        "dose": "200g"
      },
      {
        "name": "Mộc hương",
        "dose": "80g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thuoc_tay_san",
    "name": "Thuốc tẩy sán",
    "chapterNumber": 17,
    "chapterTitle": "Bài thuốc khu trùng",
    "group": "Khu trùng",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "sát trùng diệt sán"
    ],
    "indication": "sát trùng diệt sán. Bài thuốc chuyên dùng để điều trị sán",
    "herbs": [
      {
        "name": "Rễ lựu",
        "dose": "50g"
      },
      {
        "name": "Tân lang",
        "dose": "50g"
      },
      {
        "name": "Hạt bí ngô",
        "dose": "50-150g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "cao_dan_mun_nhot",
    "name": "Cao dán mụn nhọt",
    "chapterNumber": 18,
    "chapterTitle": "Bài thuốc chữa mụn nhọt - viêm tấy",
    "group": "Chữa mụn nhọt - viêm tấy",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "tiêu sưng",
      "khử hủ",
      "sinh cơ"
    ],
    "indication": "tiêu sưng, khử hủ, sinh cơ. Bài thuốc chuyên dùng để điều trị mụn nhọt",
    "herbs": [
      {
        "name": "Long não",
        "dose": "6g"
      },
      {
        "name": "Hồng đơn",
        "dose": "20g"
      },
      {
        "name": "Dầu vừng",
        "dose": "100g"
      },
      {
        "name": "Tóc rối đốt",
        "dose": "1 nắm"
      },
      {
        "name": "Nhựa thông",
        "dose": "40g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "duong_hoa_thang",
    "name": "Dương hòa thang",
    "chapterNumber": 18,
    "chapterTitle": "Bài thuốc chữa mụn nhọt - viêm tấy",
    "group": "Chữa mụn nhọt - viêm tấy",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Cốt thư",
      "viêm hạch",
      "sưng nhưng không đỏ không nóng"
    ],
    "effects": [
      "thông dương tán kết"
    ],
    "indication": "thông dương tán kết. Bài thuốc trị cốt thư, thoát thư, viêm hạch",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngan_hoa_giai_oc_thang",
    "name": "Ngân hoa giải độc thang",
    "chapterNumber": 18,
    "chapterTitle": "Bài thuốc chữa mụn nhọt - viêm tấy",
    "group": "Chữa mụn nhọt - viêm tấy",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Mụn nhọt",
      "đinh độc",
      "vết thương nhiễm trùng sưng đỏ"
    ],
    "effects": [
      "thanh nhiệt giải độc lương huyết"
    ],
    "indication": "thanh nhiệt giải độc lương huyết. Bài thuốc trị thấp nhiệt, ung thư, đinh nhọt",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "nhuan_co_cao_tam_hoang_thanh_cao",
    "name": "Nhuận cơ cao (Tam hoàng thanh cao)",
    "chapterNumber": 18,
    "chapterTitle": "Bài thuốc chữa mụn nhọt - viêm tấy",
    "group": "Chữa mụn nhọt - viêm tấy",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [],
    "indication": "",
    "herbs": [],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thuoc_boi_cham",
    "name": "Thuốc bôi chàm",
    "chapterNumber": 18,
    "chapterTitle": "Bài thuốc chữa mụn nhọt - viêm tấy",
    "group": "Chữa mụn nhọt - viêm tấy",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "thanh trừ thấp nhiệt"
    ],
    "indication": "chàm trẻ em",
    "herbs": [
      {
        "name": "Vỏ núc nác",
        "dose": "40g"
      },
      {
        "name": "Nghệ vàng",
        "dose": "20g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tieu_oc_phuong",
    "name": "Tiêu độc phương",
    "chapterNumber": 18,
    "chapterTitle": "Bài thuốc chữa mụn nhọt - viêm tấy",
    "group": "Chữa mụn nhọt - viêm tấy",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Mụn nhọt",
      "sưng tấy",
      "lở ngứa",
      "mẩn ngứa"
    ],
    "effects": [
      "thanh nhiệt tiêu độc"
    ],
    "indication": "thanh nhiệt tiêu độc. Bài thuốc trị mụn nhọt, sưng tấy, mẩn ngứa",
    "herbs": [
      {
        "name": "Sài đất",
        "dose": "30g"
      },
      {
        "name": "Sinh địa",
        "dose": "20g"
      },
      {
        "name": "Kim ngân",
        "dose": "20g"
      },
      {
        "name": "Thổ phục linh",
        "dose": "15g"
      },
      {
        "name": "Ké đầu ngựa",
        "dose": "15g"
      },
      {
        "name": "Cam thảo đất",
        "dose": "12g"
      }
    ],
    "usage": "Sắc uống lúc ấm và khi đói",
    "analysis": "Sài đất, Kim ngân (Quân) thanh nhiệt giải độc; Thổ phục linh, Ké đầu ngựa (Thần) trừ thấp giải độc; Sinh địa (Tá) lương huyết sưng đỏ; Cam thảo (Sứ) điều hòa",
    "contra": "",
    "note": ""
  },
  {
    "id": "ai_hoang_thang",
    "name": "Đại hoàng thang",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "nhuận táo",
      "dưỡng phu"
    ],
    "indication": "bệnh vẩy nến",
    "herbs": [
      {
        "name": "Đại hoàng",
        "dose": "15g"
      },
      {
        "name": "Quế chi",
        "dose": "20g"
      },
      {
        "name": "Đào nhân",
        "dose": "30g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "an_sam_cao",
    "name": "Đan sâm cao",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "hoạt huyết",
      "tiêu sưng",
      "chỉ đau"
    ],
    "indication": "hoạt huyết, tiêu sưng, chỉ đau. Bài thuốc trị chứng viêm tuyến vú giai đoạn đầu",
    "herbs": [
      {
        "name": "Đan sâm",
        "dose": "60g"
      },
      {
        "name": "Xích thược",
        "dose": "60g"
      },
      {
        "name": "Bạch chỉ",
        "dose": "30g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "cuu_nhat_an",
    "name": "Cửu nhất đan",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Các vết lở loét",
      "lỗ rò có mủ"
    ],
    "effects": [
      "bì nùng khử hủ"
    ],
    "indication": "các vết lở loét, các lỗ dò",
    "herbs": [
      {
        "name": "Thục thạch cao",
        "dose": "900g"
      },
      {
        "name": "Thăng đan",
        "dose": "100g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngoc_co_tan",
    "name": "Ngọc cơ tán",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "vinh cơ nhuận phu"
    ],
    "indication": "vinh cơ nhuận phu. Bài thuốc trị tàn nhang, sạm da, da khô nứt nẻ",
    "herbs": [
      {
        "name": "Đậu xanh",
        "dose": "250g"
      },
      {
        "name": "Bạch chỉ",
        "dose": "6g"
      },
      {
        "name": "Hoạt thạch",
        "dose": "6g"
      },
      {
        "name": "Bạch phụ tử",
        "dose": "6g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "ngu_boi_tu_thang",
    "name": "Ngũ bội tử thang",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Bệnh trĩ",
      "sa trực tràng sưng đau"
    ],
    "effects": [
      "tiêu thũng chỉ thống",
      "thu liễm chỉ huyết"
    ],
    "indication": "tiêu thũng chỉ thống, thu liễm chỉ huyết. Bài thuốc trị chứng trĩ, sa trực tràng",
    "herbs": [
      {
        "name": "Ngũ bội tử",
        "dose": "30g"
      },
      {
        "name": "Tang ký sinh",
        "dose": "30g"
      },
      {
        "name": "Phác tiêu",
        "dose": "30g"
      },
      {
        "name": "Kinh giới",
        "dose": "30g"
      },
      {
        "name": "Liên phòng",
        "dose": "30g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "nhi_phan_thang",
    "name": "Nhị phàn thang",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Tổ đỉa",
      "ngứa da",
      "da khô dầy nứt nẻ"
    ],
    "effects": [
      "sát trùng",
      "chống ngứa"
    ],
    "indication": "sát trùng, chống ngứa. Bài thuốc trị chứng tổ đỉa ở bàn tay, da dẻ khô dầy",
    "herbs": [
      {
        "name": "Bạch phàn",
        "dose": "120g"
      },
      {
        "name": "Tạo phàn",
        "dose": "120g"
      },
      {
        "name": "Nhi trà",
        "dose": "15g"
      },
      {
        "name": "Trắc bách diệp",
        "dose": "240g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "nhi_vi_bat_oc_tan",
    "name": "Nhị vị bạt độc tán",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "bại độc tiêu thũng",
      "thanh nhiệt chỉ thống"
    ],
    "indication": "các trường hợp mụn nhọt",
    "herbs": [
      {
        "name": "Minh hùng hoàng",
        "dose": "100g"
      },
      {
        "name": "Bạch phàn",
        "dose": "100g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "tam_dieu_tan",
    "name": "Tam diệu tán",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [],
    "effects": [
      "thẩm thấp chỉ dưỡng"
    ],
    "indication": "thẩm thấp chỉ dưỡng. Bài thuốc trị chàm, viêm da, mụn nhọt",
    "herbs": [
      {
        "name": "Binh lang",
        "dose": "100g"
      },
      {
        "name": "Thương thuật",
        "dose": "100g"
      },
      {
        "name": "Hoàng bá",
        "dose": "100g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "thanh_luong_cao",
    "name": "Thanh lương cao",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Bỏng nước sôi",
      "bỏng lửa sưng rát"
    ],
    "effects": [
      "thanh nhiệt giải độc",
      "nhuận cơ",
      "chỉ thống"
    ],
    "indication": "bỏng nước sôi, bỏng lửa",
    "herbs": [
      {
        "name": "Chi tử",
        "dose": "8g"
      },
      {
        "name": "Hoàng liên",
        "dose": "8g"
      },
      {
        "name": "Bạch chỉ",
        "dose": "8g"
      },
      {
        "name": "Sinh địa hoàng",
        "dose": "6g"
      },
      {
        "name": "Thông bạch",
        "dose": "10g"
      }
    ],
    "usage": "",
    "analysis": "",
    "contra": "",
    "note": ""
  },
  {
    "id": "that_ly_tan",
    "name": "Thất lý tán",
    "chapterNumber": 19,
    "chapterTitle": "Bài thuốc dùng ngoài",
    "group": "Dùng ngoài",
    "subgroup": "Các bài thuốc",
    "symptoms": [
      "Chấn thương chảy máu",
      "bầm tím",
      "đau đớn"
    ],
    "effects": [
      "hoạt huyết hoá ứ"
    ],
    "indication": "ngoại thương có chảy máu, bầm tím",
    "herbs": [
      {
        "name": "Huyết kiệt",
        "dose": "30g"
      },
      {
        "name": "Nhi trà",
        "dose": "5g"
      },
      {
        "name": "Chu sa",
        "dose": "3.6g"
      },
      {
        "name": "Hồng hoa",
        "dose": "5g"
      },
      {
        "name": "Nhũ hương",
        "dose": "4.5g"
      },
      {
        "name": "Một dược",
        "dose": "5g"
      },
      {
        "name": "Băng phiến",
        "dose": "0.36g"
      },
      {
        "name": "Xạ hương",
        "dose": "0.36g"
      }
    ],
    "usage": "",
    "analysis": "Huyết kiệt (Quân) hoạt huyết, chỉ huyết, chỉ thống; Hồng hoa, Nhũ hương, Một dược (Thần) tăng cường khứ ứ; Băng phiến, Xạ hương (Tá) thông lạc; Chu sa, Nhi trà (Sứ) trấn tĩnh, thu liễm",
    "contra": "",
    "note": ""
  }
];
function normalizeText(s){
  return (s||"").toString().trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
}
function splitKeywords(input){
  const raw=normalizeText(input);
  if(!raw) return [];
  return raw.split(/[,]+|\s+/g).map(x=>x.trim()).filter(Boolean);
}
function unique(arr){ return Array.from(new Set(arr)); }
function countMatches(keywords, haystackTokens){
  // Khớp "sát": chỉ tính khi TRÙNG token (không khớp kiểu chứa chuỗi)
  if(!keywords.length) return 0;
  let score=0;
  const set = new Set(haystackTokens || []);
  for(const kw of keywords){
    if(set.has(kw)) score += 1;
  }
  return score;
}

function allKeywordsPresent(keywords, haystackTokens){
  // Tất cả từ khóa đều phải có (AND) -> lọc chính xác hơn
  if(!keywords.length) return true;
  const set = new Set(haystackTokens || []);
  for(const kw of keywords){
    if(!set.has(kw)) return false;
  }
  return true;
}
function escapeHtml(str){
  return (str||"").toString()
    .replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;")
    .replaceAll('"',"&quot;").replaceAll("'","&#039;");
}

function tokenizeFields(remedy){
  const tokens=[];
  const push=(arr)=> (arr||[]).forEach(x=> splitKeywords(x).forEach(t=>tokens.push(t)));
  push([remedy.name, remedy.chapterTitle, remedy.group, remedy.subgroup, remedy.indication, remedy.usage, remedy.contra, remedy.analysis, remedy.note]);
  push(remedy.symptoms);
  push(remedy.effects);
  (remedy.herbs||[]).forEach(h=> push([h.name,h.dose]));
  return unique(tokens);
}

/* Elements */
const symptomInput=document.getElementById("symptomInput");
const effectInput=document.getElementById("effectInput");
const chapterSelect=document.getElementById("chapterSelect");
const clearBtn=document.getElementById("clearBtn");
const resultsEl=document.getElementById("results");
const resultCount=document.getElementById("resultCount");
const detailEl=document.getElementById("detail");
const detailTitleEl=document.getElementById("detailTitle");
const detailSubEl=document.getElementById("detailSub");
const quickChipsEl=document.getElementById("quickChips");

/* hidden */
const modeSelect=document.getElementById("modeSelect");
const sortSelect=document.getElementById("sortSelect");

let currentRemedy=null;

/* Quick chips */
const QUICK_CHIPS=[
  {label:"Ho",symptom:"ho",effect:""},
  {label:"Sốt",symptom:"sốt",effect:""},
  {label:"Đau lưng",symptom:"đau lưng",effect:""},
  {label:"Thanh nhiệt",symptom:"",effect:"thanh nhiệt"},
  {label:"Trừ đàm",symptom:"",effect:"trừ đàm"},
  {label:"Bổ khí",symptom:"",effect:"bổ khí"},
];

function renderChips(){
  quickChipsEl.innerHTML="";
  QUICK_CHIPS.forEach(c=>{
    const div=document.createElement("div");
    div.className="chip";
    div.textContent=c.label;
    div.onclick=()=>{
      if(c.symptom) symptomInput.value=c.symptom;
      if(c.effect) effectInput.value=c.effect;
      runSearch();
    };
    quickChipsEl.appendChild(div);
  });
}

function buildChapterSelect(){
  const map=new Map();
  for(const r of REMEDIES){
    map.set(r.chapterNumber, r.chapterTitle);
  }
  const nums=Array.from(map.keys()).sort((a,b)=>a-b);
  for(const n of nums){
    const opt=document.createElement("option");
    opt.value=String(n);
    opt.textContent=`Chương ${n}: ${map.get(n)}`;
    chapterSelect.appendChild(opt);
  }
}

const INDEX=REMEDIES.map(r=>({
  remedy:r,
  tokensSymptoms:unique((r.symptoms||[]).flatMap(s=>splitKeywords(s))),
  tokensEffects:unique((r.effects||[]).flatMap(s=>splitKeywords(s)).concat(splitKeywords(r.indication)))
}));

function badgeText(score){
  if(score>=6) return "Khớp cao";
  if(score>=3) return "Khớp vừa";
  return "Khớp";
}

function renderResults(items){
  resultsEl.innerHTML="";
  resultCount.textContent=String(items.length);

  if(!items.length){
    resultsEl.innerHTML=`<div class="empty">Không có kết quả. Thử đổi từ khóa.</div>`;
    return;
  }

  items.forEach(({remedy,score})=>{
    const card=document.createElement("div");
    card.className="remedy-card";
    card.innerHTML=`
      <h3 class="remedy-name">${escapeHtml(remedy.name)}</h3>
      <div class="remedy-meta">Chương ${remedy.chapterNumber}: ${escapeHtml(remedy.chapterTitle)}</div>
      <div class="remedy-meta">${badgeText(score)} • ${score}</div>
    `;
    card.onclick=()=>renderDetail(remedy);
    resultsEl.appendChild(card);
  });
}

function joinHerbsSentence(herbs){
  if(!herbs || !herbs.length) return "";
  return herbs.map(h=> `${h.name}${h.dose?` ${h.dose}`:""}`).join(", ") + ".";
}

function renderSection(title, content){
  const safe = content && content.trim() ? content : "Chưa có dữ liệu.";
  return `
    <div class="section">
      <h3>${escapeHtml(title)}</h3>
      <div class="text">${escapeHtml(safe)}</div>
    </div>
  `;
}

function renderDetail(remedy){
  currentRemedy=remedy;
  detailTitleEl.textContent=remedy.name;
  detailSubEl.textContent=`Chương ${remedy.chapterNumber}: ${remedy.chapterTitle}`;

  const effectsLine = (remedy.effects && remedy.effects.length) ? remedy.effects.join(", ") : "";
  const congDung = effectsLine ? `${effectsLine}.` : "";
  const chiDinh = remedy.indication || "";

  const thanhPhan = joinHerbsSentence(remedy.herbs);
  const trieuChung = (remedy.symptoms && remedy.symptoms.length) ? remedy.symptoms.join(", ") + "." : "";

  const usage = remedy.usage || "";
  const analysis = remedy.analysis || "";

  detailEl.innerHTML =
    renderSection("Công dụng / Điều trị", congDung || chiDinh) +
    renderSection("Thành phần và khối lượng", thanhPhan) +
    renderSection("Triệu chứng", trieuChung) +
    renderSection("Cách dùng", usage) +
    renderSection("Chỉ định", chiDinh) +
    renderSection("Phân tích (Quân – Thần – Tá – Sứ / vai trò vị thuốc)", analysis);
}

function clearDetail(){
  currentRemedy=null;
  detailTitleEl.textContent="Chọn một bài thuốc";
  detailSubEl.textContent="—";
  detailEl.innerHTML=`<div class="empty">Chọn 1 bài thuốc bên trái để xem chi tiết.</div>`;
}

function runSearch(){
  const symptomKeywords=splitKeywords(symptomInput.value);
  const effectKeywords=splitKeywords(effectInput.value);
  const chap = chapterSelect.value;

  const hasSymptom=symptomKeywords.length>0;
  const hasEffect=effectKeywords.length>0;

  let results=INDEX.map(item=>{
    const r=item.remedy;

    // Chỉ tìm theo đúng mục:
    // - Triệu chứng -> symptoms
    // - Công dụng/Điều trị -> effects + indication
    const sOk = hasSymptom ? allKeywordsPresent(symptomKeywords, item.tokensSymptoms) : true;
    const eOk = hasEffect ? allKeywordsPresent(effectKeywords, item.tokensEffects) : true;

    const sScore = (hasSymptom && sOk) ? countMatches(symptomKeywords, item.tokensSymptoms) : 0;
    const eScore = (hasEffect && eOk) ? countMatches(effectKeywords, item.tokensEffects) : 0;

    // Điểm = tổng điểm 2 mục (không dùng khớp lan sang mục khác)
    const score = (sScore*2) + (eScore*2);

    return { remedy:r, score, sScore, eScore, sOk, eOk };
  });

  if(chap !== "all"){
    const chapNum = parseInt(chap, 10);
    results = results.filter(x => x.remedy.chapterNumber === chapNum);
  }

  if(hasSymptom || hasEffect){
    results = results.filter(r=>{
      if(hasSymptom && hasEffect) return r.sOk && r.eOk;
      if(hasSymptom) return r.sOk;
      if(hasEffect) return r.eOk;
      return true;
    });
  }

  results.sort((a,b)=> (b.score-a.score) || a.remedy.name.localeCompare(b.remedy.name,"vi"));
  renderResults(results);
}

function bindEvents(){
  symptomInput.addEventListener("input", runSearch);
  effectInput.addEventListener("input", runSearch);
  chapterSelect.addEventListener("change", runSearch);

  clearBtn.onclick=()=>{
    symptomInput.value="";
    effectInput.value="";
    chapterSelect.value="all";
    clearDetail();
    runSearch();
  };
}

buildChapterSelect();
renderChips();
bindEvents();
clearDetail();
runSearch();


/* ===== Anti pull-to-refresh / rubber-band (Chrome Android & Safari iOS) ===== */
(function(){
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  // Trên desktop/tablet body đã overflow:hidden; trên mobile 1 cột thì dùng guard này để tránh "bounce" gây cảm giác reload.
  const scrollers = ['.list', '.detail-body'];

  function closestScroller(el){
    while(el){
      if(el.classList && (el.classList.contains('list') || el.classList.contains('detail-body'))) return el;
      el = el.parentElement;
    }
    return null;
  }

  // iOS: chặn overscroll ở đầu/cuối vùng cuộn
  if(isIOS){
    let startY = 0;
    document.addEventListener('touchstart', (e)=>{
      const t = e.touches && e.touches[0];
      if(!t) return;
      startY = t.clientY;
    }, {passive:true});

    document.addEventListener('touchmove', (e)=>{
      const t = e.touches && e.touches[0];
      if(!t) return;

      const target = e.target;
      const scroller = closestScroller(target);

      // Nếu kéo trên vùng không phải scroller -> chặn để tránh bounce toàn trang
      if(!scroller){
        e.preventDefault();
        return;
      }

      const dy = t.clientY - startY;
      const atTop = scroller.scrollTop <= 0;
      const atBottom = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 1;

      // Kéo xuống khi đang ở top, hoặc kéo lên khi đang ở bottom -> chặn bounce
      if((dy > 0 && atTop) || (dy < 0 && atBottom)){
        e.preventDefault();
      }
    }, {passive:false});
  }

  // Chrome Android: overscroll-behavior đã xử lý phần lớn; thêm prevent cho vùng ngoài scroller khi body overflow:auto (mobile)
  document.addEventListener('wheel', (e)=>{
    const scroller = closestScroller(e.target);
    if(!scroller && window.matchMedia && window.matchMedia('(max-width: 900px)').matches){
      // nếu cuộn ở vùng trống -> để tránh cuộn body quá đà
      e.preventDefault();
    }
  }, {passive:false});
})();

